import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { Chess, Piece, Square, Move } from 'chess.js';
import { Chessboard } from 'react-chessboard';
import { Grid, Paper, Typography, Button, Box, Modal, CircularProgress } from '@mui/material';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext'; 
import { db } from '../firebase';
import { doc, setDoc, updateDoc, increment, collection, serverTimestamp, getDocs, query, where, FieldValue, onSnapshot } from 'firebase/firestore';
import ConfirmationDialog from '../components/ConfirmationDialog';
import ChessIcon from '../components/ChessIcon';
import { GameHistory, UnlockedAchievement } from '../types';
import { achievementsList } from '../data/achievements';

const pieceComponents: { [key: string]: string } = {
    wK: '♚', wQ: '♛', wR: '♜', wB: '♝', wN: '♞', wP: '♟︎',
    bK: '♚', bQ: '♛', bR: '♜', bB: '♝', bN: '♞', bP: '♟︎'
};

const CapturedPieces = ({ title, pieces, variant = 'dark' }: { title: string, pieces: Piece[], variant?: 'dark' | 'light' }) => {
    const style = variant === 'dark' 
        ? { background: 'rgba(128, 128, 128, 0.3)', color: 'white' }
        : { background: 'rgba(230, 230, 230, 0.85)', color: 'black' };

    return (
        <Paper elevation={4} sx={{ p: 1, my: 1, minHeight: '70px', width: '100%', borderRadius: '10px', ...style }}>
            <Typography variant="subtitle2" align="center" sx={{ height: '20px', color: 'inherit' }}>{title}</Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'center', mt: 1 }}>
                {pieces.map((p, i) => <div key={i} style={{ fontSize: '24px', margin: '0 2px' }}>{pieceComponents[p.color + p.type.toUpperCase()]}</div>)}
            </Box>
        </Paper>
    );
};

const getAiMove = (game: Chess) => {
    const possibleMoves = game.moves({ verbose: true });
    if (possibleMoves.length === 0) return null;
    
    const captureMoves = possibleMoves.filter(m => m.captured);
    if (captureMoves.length > 0) {
        return captureMoves[Math.floor(Math.random() * captureMoves.length)];
    }
    
    return possibleMoves[Math.floor(Math.random() * possibleMoves.length)];
};

const getPieceValue = (pieceType: string) => {
    const values: { [key: string]: number } = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
    return values[pieceType.toLowerCase()];
};

const PlayAI = () => {
    const { currentUser, userProfile, resetAiStats, loading, isUpdating } = useAuth();
    const gameRef = useRef(new Chess());

    const [fen, setFen] = useState(gameRef.current.fen());
    const [gameResult, setGameResult] = useState<'win' | 'loss' | 'draw' | null>(null);
    const [isThinking, setIsThinking] = useState(false);
    const [capturedPieces, setCapturedPieces] = useState<{ w: Piece[], b: Piece[] }>({ w: [], b: [] });
    const [boardWidth, setBoardWidth] = useState(560);
    const chessboardContainerRef = useRef<HTMLDivElement>(null);
    const [isResetStatsDialogOpen, setResetStatsDialogOpen] = useState(false);
    const [fromSquare, setFromSquare] = useState<Square | null>(null);
    const [optionSquares, setOptionSquares] = useState<{[key: string]: React.CSSProperties}>({});

    const [localStats, setLocalStats] = useState({
        gamesPlayed: 0,
        gamesWon: 0,
        gamesLost: 0,
        draws: 0,
        winPercentage: 0
    });

    useEffect(() => {
        if (!currentUser) return;
        const userRef = doc(db, 'users', currentUser.uid);
        const unsubscribe = onSnapshot(userRef, (docSnap) => {
            if (docSnap.exists()) {
                const data = docSnap.data();
                if (data.aiStats) {
                    setLocalStats({
                        gamesPlayed: data.aiStats.gamesPlayed || 0,
                        gamesWon: data.aiStats.gamesWon || 0,
                        gamesLost: data.aiStats.gamesLost || 0,
                        draws: data.aiStats.draws || 0,
                        winPercentage: data.aiStats.winPercentage || 0
                    });
                }
            }
        });
        return () => unsubscribe();
    }, [currentUser]);

    useEffect(() => {
        const updateSize = () => {
            if (chessboardContainerRef.current) {
                const { offsetWidth, offsetHeight } = chessboardContainerRef.current;
                setBoardWidth(Math.min(offsetWidth, offsetHeight, 560));
            }
        };
        window.addEventListener('resize', updateSize);
        updateSize();
        return () => window.addEventListener('resize', updateSize);
    }, []);

    const aiLevel = userProfile?.aiStats?.level || 'Easy';

    const checkAndUnlockAchievements = useCallback(async (result: 'win' | 'loss' | 'draw') => {
        if (!currentUser || result !== 'win') return;

        const unlockedAchievementsRef = collection(db, 'users', currentUser.uid, 'unlockedAchievements');
        const unlockedSnapshot = await getDocs(unlockedAchievementsRef);
        const unlockedIds = unlockedSnapshot.docs.map(doc => doc.id);

        const gameHistoryRef = collection(db, 'users', currentUser.uid, 'gameHistory');

        for (const achievement of achievementsList) {
            if (unlockedIds.includes(achievement.id)) continue;

            let unlock = false;
            switch (achievement.id) {
                case 'first_win_ai':
                    unlock = true;
                    break;
                case 'ten_wins_ai':
                    const aiWinsQuery = query(gameHistoryRef, where('gameType', '==', 'ai'), where('result', '==', 'win'));
                    const aiWinsSnapshot = await getDocs(aiWinsQuery);
                    if (aiWinsSnapshot.size >= 9) unlock = true;
                    break;
                case 'flawless_victory':
                    if (!gameRef.current.history({ verbose: true }).some(move => move.captured && move.color === 'b')) unlock = true;
                    break;
            }

            if (unlock) {
                const unlockedAchievementDoc: Partial<UnlockedAchievement> & { unlockedAt: FieldValue } = {
                    id: achievement.id,
                    name: achievement.name,
                    description: achievement.description,
                    unlockedAt: serverTimestamp(),
                };
                await setDoc(doc(unlockedAchievementsRef, achievement.id), unlockedAchievementDoc);
            }
        }
    }, [currentUser]);

    const handleGameEnd = useCallback(async (result: 'win' | 'loss' | 'draw') => {
        if (gameResult) return;
        setGameResult(result);
        await checkAndUnlockAchievements(result);

        if (currentUser) {
            const gameId = `ai-${Date.now()}`;
            
            // Immediate Local Update
            setLocalStats(prev => {
                const updated = {
                    gamesPlayed: prev.gamesPlayed + 1,
                    gamesWon: result === 'win' ? prev.gamesWon + 1 : prev.gamesWon,
                    gamesLost: result === 'loss' ? prev.gamesLost + 1 : prev.gamesLost,
                    draws: result === 'draw' ? prev.draws + 1 : prev.draws,
                    winPercentage: prev.winPercentage
                };
                updated.winPercentage = updated.gamesPlayed > 0 
                    ? Math.round((updated.gamesWon / updated.gamesPlayed) * 100) 
                    : 0;
                return updated;
            });

            // Firestore Update
            const userRef = doc(db, 'users', currentUser.uid);
            const statsUpdate: any = {
                'aiStats.gamesPlayed': increment(1)
            };
            if (result === 'win') statsUpdate['aiStats.gamesWon'] = increment(1);
            else if (result === 'loss') statsUpdate['aiStats.gamesLost'] = increment(1);
            else if (result === 'draw') statsUpdate['aiStats.draws'] = increment(1);

            try {
                await updateDoc(userRef, statsUpdate);
                
                // Fetch the latest doc to recalculate win percentage accurately in DB
                const userSnap = await getDocs(query(collection(db, 'users'), where('uid', '==', currentUser.uid)));
                if (!userSnap.empty) {
                    const currentData = userSnap.docs[0].data();
                    const stats = currentData.aiStats;
                    const gamesPlayed = stats.gamesPlayed || 0;
                    const gamesWon = stats.gamesWon || 0;
                    const newWinPct = gamesPlayed > 0 ? Math.round((gamesWon / gamesPlayed) * 100) : 0;
                    await updateDoc(userRef, { 'aiStats.winPercentage': newWinPct });
                }
            } catch (error) {
                console.error("Error updating AI stats:", error);
            }

            const gameHistoryEntry: Omit<GameHistory, 'playedAt'> & { playedAt: FieldValue } = {
                gameId: gameId,
                opponent: { uid: 'ai', name: `AI (${aiLevel})`, photoURL: '' },
                result: result,
                playedAt: serverTimestamp(),
                gameType: 'AI'
            };

            try {
                await setDoc(doc(collection(db, 'users', currentUser.uid, 'gameHistory'), gameHistoryEntry.gameId), gameHistoryEntry);
            } catch (error) {
                console.error("Error saving game history:", error);
            }
        }
    }, [gameResult, currentUser, aiLevel, checkAndUnlockAchievements]);

    const checkGameState = useCallback((currentGame: Chess) => {
        if (currentGame.isGameOver()) {
            if (currentGame.isCheckmate()) handleGameEnd(currentGame.turn() === 'b' ? 'win' : 'loss');
            else if (currentGame.isDraw() || currentGame.isStalemate() || currentGame.isThreefoldRepetition() || currentGame.isInsufficientMaterial()) handleGameEnd('draw');
            return true;
        }
        return false;
    }, [handleGameEnd]);

    const processMove = (move: Move) => {
        if (move.captured) {
            const capturedPiece: Piece = { type: move.captured, color: move.color === 'w' ? 'b' : 'w' };
            setCapturedPieces(prev => ({
                ...prev,
                [move.color === 'w' ? 'b' : 'w']: [...prev[move.color === 'w' ? 'b' : 'w'], capturedPiece].sort((a, b) => getPieceValue(b.type) - getPieceValue(a.type))
            }));
        }
    };
    
    const makeAiMove = useCallback(() => {
        if (checkGameState(gameRef.current) || gameRef.current.turn() === 'w') return;
        setIsThinking(true);
        setTimeout(() => {
            const move = getAiMove(gameRef.current);
            if (move) {
                const gameCopy = new Chess(gameRef.current.fen());
                const fullMove = gameCopy.move(move);
                if (fullMove) {
                    gameRef.current = gameCopy;
                    setFen(gameCopy.fen());
                    processMove(fullMove);
                    checkGameState(gameCopy);
                }
            }
            setIsThinking(false);
        }, 1200);
    }, [checkGameState]);
    
    const makeAMove = (move: { from: Square; to: Square; promotion?: string }) => {
        const gameCopy = new Chess(gameRef.current.fen());
        try {
            const result = gameCopy.move(move);
            if (result) {
                gameRef.current = gameCopy;
                setFen(gameCopy.fen());
                processMove(result);
                if (!checkGameState(gameCopy)) makeAiMove();
            }
            return result;
        } catch (e) {
            return null;
        }
    }

    const getMoveOptions = (square: Square) => {
        const moves = gameRef.current.moves({ square, verbose: true });
        if (moves.length === 0 || gameRef.current.get(square)?.color !== gameRef.current.turn()) {
            setOptionSquares({});
            setFromSquare(null);
            return false;
        }
        const newSquares: { [key: string]: React.CSSProperties } = {};
        moves.forEach(move => {
            newSquares[move.to] = {
                background: gameRef.current.get(move.to) && gameRef.current.get(move.to)?.color !== gameRef.current.get(square)?.color
                    ? 'radial-gradient(circle, rgba(0,0,0,.1) 85%, #4A90E2 85%)' : 'radial-gradient(circle, #4A90E2 30%, transparent 30%)',
                borderRadius: '50%',
            };
        });
        newSquares[square] = { background: 'rgba(74, 144, 226, 0.4)' };
        setOptionSquares(newSquares);
        return true;
    }

    const onSquareClick = (square: Square) => {
        if (gameRef.current.turn() !== 'w' || isThinking || gameResult) return;
        if (!fromSquare) {
            if (getMoveOptions(square)) setFromSquare(square);
            return;
        }
        if (fromSquare === square) {
            setFromSquare(null);
            setOptionSquares({});
            return;
        }
        if (makeAMove({ from: fromSquare, to: square, promotion: 'q' }) === null) {
            if (getMoveOptions(square)) setFromSquare(square);
        } else {
           setFromSquare(null);
           setOptionSquares({});
        }
    }
    
    const onSquareRightClick = () => {
        setOptionSquares({});
        setFromSquare(null);
    }
    
    const onDrop = (sourceSquare: Square, targetSquare: Square) => {
        if (isThinking || gameResult) return false;
        if (makeAMove({ from: sourceSquare, to: targetSquare, promotion: 'q' }) === null) return false;
        setFromSquare(null);
        setOptionSquares({});
        return true;
    }

    const resetGame = (isNewGame: boolean = true) => {
        if (isNewGame) {
          gameRef.current = new Chess();
          setFen(gameRef.current.fen());
        }
        setGameResult(null);
        setCapturedPieces({ w: [], b: [] });
        setFromSquare(null);
        setOptionSquares({});
        setIsThinking(false);
    };
    
    const handleResetStats = async () => {
        setResetStatsDialogOpen(false);
        await resetAiStats();
        setLocalStats({ gamesPlayed: 0, gamesWon: 0, gamesLost: 0, draws: 0, winPercentage: 0 });
        resetGame(false);
    };
    
    const customPieces = useMemo(() => {
        const pieceRenderer = (piece: string, color: string, isBlack: boolean = false) => ({ squareWidth }: { squareWidth: number }) => (
            <div style={{ width: squareWidth, height: squareWidth, display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: squareWidth * 0.75, color: color, textShadow: isBlack ? '-1px -1px 0 #FFF, 1px -1px 0 #FFF, -1px 1px 0 #FFF, 1px 1px 0 #FFF, -2px -2px 5px rgba(0,0,0,0.3)' : '0px 2px 4px rgba(0, 0, 0, 0.5)' }}>
                {piece}
            </div>
        );
        return {
            wK: pieceRenderer(pieceComponents.wK, '#FFFFFF'), wQ: pieceRenderer(pieceComponents.wQ, '#FFFFFF'), wR: pieceRenderer(pieceComponents.wR, '#FFFFFF'), wB: pieceRenderer(pieceComponents.wB, '#FFFFFF'), wN: pieceRenderer(pieceComponents.wN, '#FFFFFF'), wP: pieceRenderer(pieceComponents.wP, '#FFFFFF'),
            bK: pieceRenderer(pieceComponents.bK, '#1A1A1A', true), bQ: pieceRenderer(pieceComponents.bQ, '#1A1A1A', true), bR: pieceRenderer(pieceComponents.bR, '#1A1A1A', true), bB: pieceRenderer(pieceComponents.bB, '#1A1A1A', true), bN: pieceRenderer(pieceComponents.bN, '#1A1A1A', true), bP: pieceRenderer(pieceComponents.bP, '#1A1A1A', true),
        };
    }, []);

    if (loading && !currentUser) return <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}><CircularProgress /></Box>;

    return (
        <Box sx={{ p: { xs: 1, sm: 2, md: 4 } }}>
            <Grid container spacing={4} justifyContent="center" alignItems="flex-start">
                <Grid item xs={12} md={8} ref={chessboardContainerRef} sx={{ order: { xs: 1, md: 1 }, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <Box sx={{ width: boardWidth * 0.9, mb: 1}}>
                        <CapturedPieces title={isThinking ? "AI is thinking..." : "AI's Captures"} pieces={capturedPieces.w} />
                    </Box>
                    <Paper elevation={10} sx={{ p: 2, background: 'rgba(255, 255, 255, 0.1)', backdropFilter: 'blur(10px)', borderRadius: '15px', display: 'inline-block' }}>
                        <Chessboard 
                            position={fen} 
                            onPieceDrop={onDrop} 
                            onSquareClick={onSquareClick} 
                            onSquareRightClick={onSquareRightClick} 
                            customSquareStyles={optionSquares} 
                            customPieces={customPieces} 
                            boardWidth={boardWidth} 
                            customBoardStyle={{ borderRadius: '8px', boxShadow: '0 5px 15px rgba(0, 0, 0, 0.5)' }} 
                            customDarkSquareStyle={{ backgroundColor: '#6B3F23' }} 
                            customLightSquareStyle={{ backgroundColor: '#EAD8C3' }} 
                        />
                    </Paper>
                    <Box sx={{ width: boardWidth * 0.9, mt: 1}}>
                        <CapturedPieces title="Your Captures" pieces={capturedPieces.b} variant="light" />
                    </Box>
                </Grid>

                <Grid item xs={12} md={4} sx={{ order: { xs: 2, md: 2 } }}>
                     <Paper elevation={10} sx={{ p: 3, background: 'rgba(30, 41, 59, 0.8)', backdropFilter: 'blur(10px)', borderRadius: '15px', color: 'white', textAlign: 'center' }}>
                        <Box sx={{ mb: 2 }}><ChessIcon /></Box>
                        <Typography variant="h5" sx={{ fontFamily: 'Orbitron', mb: 1, color: '#FFA500', fontWeight: 'bold' }}>PLAY WITH AI</Typography>
                        <Typography variant="subtitle1">Level: <span style={{ color: '#FFA500' }}>{aiLevel}</span></Typography>
                        
                        {/* Live Scoreboard */}
                        <Box sx={{ mt: 2, p: 2, borderRadius: '10px', background: 'rgba(255, 255, 255, 0.05)', display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 1.5 }}>
                            <Typography variant="body2">Total: <span style={{ color: '#FFA500', fontWeight: 'bold' }}>{localStats.gamesPlayed}</span></Typography>
                            <Typography variant="body2">Wins: <span style={{ color: '#32CD32', fontWeight: 'bold' }}>{localStats.gamesWon}</span></Typography>
                            <Typography variant="body2">Losses: <span style={{ color: '#FF6347', fontWeight: 'bold' }}>{localStats.gamesLost}</span></Typography>
                            <Typography variant="body2">Draws: <span style={{ color: '#888', fontWeight: 'bold' }}>{localStats.draws}</span></Typography>
                            <Typography variant="body2">Win%: <span style={{ color: '#FFD700', fontWeight: 'bold' }}>{localStats.winPercentage}%</span></Typography>
                        </Box>
                    </Paper>
                    <Box sx={{ mt: 3, display: 'flex', justifyContent: 'center', gap: 2, mb: { xs: '80px', md: 0 } }}>
                         <Button variant="contained" onClick={() => resetGame(true)} sx={{ bgcolor: '#4CAF50', '&:hover': { bgcolor: '#66BB6A' }, fontFamily: 'Orbitron', fontSize: '0.9rem', padding: '6px 12px' }}>New Game</Button>
                        <Button variant="contained" onClick={() => setResetStatsDialogOpen(true)} sx={{ bgcolor: '#f44336', '&:hover': { bgcolor: '#E57373' }, fontFamily: 'Orbitron', fontSize: '0.9rem', padding: '6px 12px' }} disabled={isUpdating}>
                            {isUpdating ? <CircularProgress size={24} color="inherit" /> : 'Reset Stats'}
                        </Button>
                    </Box>
                </Grid>
            </Grid>
            
            <ConfirmationDialog open={isResetStatsDialogOpen} onClose={() => setResetStatsDialogOpen(false)} onConfirm={handleResetStats} title="Reset Statistics?" description="Are you sure you want to reset all your AI game stats? This action cannot be undone." />

            <Modal open={!!gameResult} onClose={() => setGameResult(null)} sx={{ backdropFilter: 'blur(5px)' }}>
                <Box sx={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: { xs: '90%', sm: 400, md: 500 }, bgcolor: '#1a1a2e', border: '2px solid #FFA500', borderRadius: '20px', boxShadow: 24, p: 4, textAlign: 'center', color: 'white' }}>
                    {gameResult === 'win' ? (
                        <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
                            <Typography variant="h3" sx={{ fontFamily: 'Orbitron', color: '#FFD700' }}>🎉 Congratulations! 🎉</Typography>
                            <Typography variant="h1" sx={{ my: 2 }}>🏆</Typography>
                            <Typography variant="h6">You are one step closer to becoming a grandmaster!</Typography>
                        </motion.div>
                    ) : gameResult === 'loss' ? (
                        <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
                            <Typography variant="h4" sx={{ fontFamily: 'Orbitron', color: '#FF6347' }}>Don&apos;t give up!</Typography>
                            <Typography variant="h6" sx={{ my: 3 }}>&quot;Every master was once a beginner.&quot;</Typography>
                            <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
                                <Button variant="contained" href="/tutorials" sx={{ bgcolor: '#1E90FF' }}>Learn</Button>
                                <Button variant="contained" onClick={() => { setGameResult(null); resetGame(true); }} sx={{ bgcolor: '#32CD32' }}>Try Again</Button>
                            </Box>
                        </motion.div>
                    ) : (
                        <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
                        <Typography variant="h4">It&apos;s a Draw!</Typography>
                        </motion.div>
                    )}
                     <Button onClick={() => { setGameResult(null); resetGame(true); }} sx={{ mt: 4, color: 'white' }}>Play Again</Button>
                </Box>
            </Modal>
        </Box>
    );
};

export default PlayAI;