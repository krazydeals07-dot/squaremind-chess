
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { db } from '../firebase';
import {
    doc, onSnapshot, updateDoc, arrayUnion, collection, query,
    where, getDocs, limit, setDoc, serverTimestamp, getDoc, runTransaction
} from 'firebase/firestore';
import { useAuth } from '../contexts/AuthContext';
import { Box, Typography, Button, Card, CardContent, Grid, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, CircularProgress, List, ListItem, ListItemText, Alert } from '@mui/material';
import { styled } from '@mui/material/styles';
import { toast } from 'react-hot-toast';
import { Match, Tournament, Player } from '../utils/firebase/tournaments';
import JoinTournamentForm from '../components/JoinTournamentForm';
import PlayerStatus from '../components/PlayerStatus';
import { Chess } from 'chess.js';

const generateGameId = (length = 9) => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
};

interface LeaderboardPlayer {
    uid: string;
    displayName: string;
    points: number;
    wins: number;
}

const StyledCard = styled(Card)(({ theme }) => ({
  background: 'linear-gradient(145deg, #0A1F44, #1A3A6D)',
  color: 'white',
  borderRadius: '15px',
  padding: theme.spacing(3),
  boxShadow: '0 8px 16px rgba(0, 0, 0, 0.3)',
}));

const StyledButton = styled(Button)(() => ({
  background: '#FF6F00',
  color: 'white',
  fontWeight: 'bold',
  borderRadius: '10px',
  padding: '10px 20px',
  '&:hover': {
    background: '#FF8F00',
  },
  '&:disabled': {
    background: '#555',
    color: '#999',
  }
}));

const KNOCKOUT_TOURNAMENT_ID = 'daily-knockout';

const KnockoutTournament = () => {
  const { id: idFromParams } = useParams<{ id: string }>();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [leaderboard, setLeaderboard] = useState<LeaderboardPlayer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isJoining, setIsJoining] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const tournamentId = idFromParams || KNOCKOUT_TOURNAMENT_ID;

   useEffect(() => {
    const unsubTournament = onSnapshot(doc(db, 'tournaments', tournamentId),
      (doc) => {
        if (doc.exists()) {
            setTournament(doc.data() as Tournament);
        } else {
            setError('Tournament not found or not yet created for today.');
        }
        setLoading(false);
      },
      (err) => {
        console.error("Tournament snapshot error: ", err);
        toast.error(`Failed to load tournament info: ${err.message}`);
        setLoading(false);
      }
    );

    const unsubLeaderboard = onSnapshot(doc(db, 'daily_leaderboards', new Date().toISOString().slice(0, 10)),
      (doc) => {
          if (doc.exists()) {
              setLeaderboard(doc.data().scores || []);
          }
      },
      (err) => {
        console.error("Leaderboard snapshot error: ", err);
      }
    );

    return () => {
      unsubTournament();
      unsubLeaderboard();
    };
  }, [tournamentId]);

  const handleOpenForm = async () => {
      if (!currentUser) {
        toast.error("Please log in to join the tournament.");
        navigate('/login');
        return;
    }

    const userDocRef = doc(db, 'users', currentUser.uid);
    const userDoc = await getDoc(userDocRef);

    if (userDoc.exists()) {
        const userData = userDoc.data();
        if (userData.address && userData.mobileNumber && userData.dob) {
            handleJoin();
        } else {
            setIsFormOpen(true);
        }
    } else {
        setIsFormOpen(true);
    }
  }

 const handleJoin = async () => {
    if (!currentUser || !tournament) {
        toast.error("Please log in or wait for the tournament to load.");
        return;
    }

    setIsJoining(true);
    const toastId = toast.loading('Searching for an opponent...');

    try {
        const playerCurrentMatch = tournament.matches.find(m => 
            (m.player1?.uid === currentUser.uid || m.player2?.uid === currentUser.uid) && m.status !== 'completed'
        );

        if (playerCurrentMatch && playerCurrentMatch.gameId) {
            toast.success("Redirecting to your match...", { id: toastId });
            navigate(`/tournament/${tournamentId}/game/${playerCurrentMatch.gameId}`);
            setIsJoining(false);
            return;
        } 
        
        if (playerCurrentMatch && playerCurrentMatch.status === 'waiting') {
            toast.info("You are already in the queue. Waiting for an opponent.", { id: toastId });
            setIsJoining(false);
            return;
        }

        await runTransaction(db, async (transaction) => {
            const tournamentRef = doc(db, "tournaments", tournamentId);
            const tournamentDoc = await transaction.get(tournamentRef);
            if (!tournamentDoc.exists()) throw new Error("Tournament not found.");

            const currentTournament = tournamentDoc.data() as Tournament;
            const matches = [...currentTournament.matches];
            const currentPlayer = { uid: currentUser.uid, displayName: currentUser.displayName || 'Player', photoURL: currentUser.photoURL || '' };

            let matchToJoinIndex = matches.findIndex(m => 
                m.round === 1 && m.status === 'waiting' && m.player1 && !m.player2 && m.player1.uid !== currentUser.uid
            );

            if (matchToJoinIndex !== -1) {
                const match = matches[matchToJoinIndex];
                match.player2 = currentPlayer;
                match.status = 'ongoing';
                
                if (!match.gameId) {
                   console.error("CRITICAL: Waiting match has no gameId!");
                   match.gameId = generateGameId();
                   const gameRef = doc(db, 'games', match.gameId);
                    transaction.set(gameRef, {
                        players: { white: match.player1!.uid, black: match.player2.uid },
                        playerNames: { white: match.player1!.displayName, black: match.player2.displayName },
                        moves: [], status: 'ongoing', createdAt: serverTimestamp(),
                        chat: [], tournamentId: tournamentId, matchId: match.id, fen: new Chess().fen(),
                        timeControl: { initial: 8 * 60, increment: 2 },
                        timers: { white: 8 * 60, black: 8 * 60, lastMoveTimestamp: serverTimestamp() }
                    });
                } else {
                    const gameRef = doc(db, 'games', match.gameId);
                    transaction.update(gameRef, {
                        'players.black': match.player2.uid,
                        'playerNames.black': match.player2.displayName,
                        status: 'ongoing'
                    });
                }

                matches[matchToJoinIndex] = match;
                transaction.update(tournamentRef, { matches });
                toast.success("Opponent found! Joining game...", { id: toastId });
                navigate(`/tournament/${tournamentId}/game/${match.gameId}`);
            } else {
                const newMatchId = `${tournamentId}-r1-m${matches.filter(m => m.round === 1).length + 1}`;
                const newGameId = generateGameId();
                
                const newMatch: Match = {
                    id: newMatchId,
                    round: 1,
                    player1: currentPlayer,
                    player2: null,
                    status: 'waiting',
                    gameId: newGameId
                };
                matches.push(newMatch);

                const gameRef = doc(db, 'games', newGameId);
                transaction.set(gameRef, {
                    players: { white: currentPlayer.uid, black: null },
                    playerNames: { white: currentPlayer.displayName, black: "Waiting for opponent..." },
                    moves: [], status: 'waiting', createdAt: serverTimestamp(),
                    chat: [], tournamentId: tournamentId, matchId: newMatchId, fen: new Chess().fen(),
                    timeControl: { initial: 8 * 60, increment: 2 },
                    timers: { white: 8 * 60, black: 8 * 60, lastMoveTimestamp: serverTimestamp() }
                });
                
                const playerExists = currentTournament.players.some(p => p.uid === currentPlayer.uid);
                const updatedPlayers = playerExists ? currentTournament.players : [...currentTournament.players, currentPlayer];
                
                transaction.update(tournamentRef, { matches: matches, players: updatedPlayers });
                toast.success("You're in the queue! We'll match you with an opponent shortly.", { id: toastId });
                navigate(`/tournament/${tournamentId}/game/${newGameId}`);
            }
        });
    } catch (err) {
        console.error("Error joining tournament:", err);
        const errorMessage = err instanceof Error ? err.message : "An unknown error occurred";
        toast.error(`Failed to join: ${errorMessage}`, { id: toastId });
    } finally {
        setIsJoining(false);
    }
};


  const rules = [
    'Players are auto-paired upon joining.',
    'Each match uses a 8-minute timer per player, with a 2-second increment per move.',
    'Winning 7 consecutive games makes you a Daily Winner!',
    'Prizes are awarded to the top 10 players daily.',
    'Cheating will result in a permanent ban.',
  ];

  if (loading) {
    return <CircularProgress />
  }

  if (error) {
    return <Alert severity="error">{error}</Alert>;
  }

  return (
    <Box sx={{ p: 3, background: '#0A1F44', minHeight: '100vh', color: 'white' }}>
       <JoinTournamentForm 
          open={isFormOpen}
          onClose={() => setIsFormOpen(false)}
          onJoin={handleJoin}
        />
      <Grid container spacing={4}>
        <Grid item xs={12} md={6}>
          <StyledCard>
            <CardContent>
              <Typography variant="h4" gutterBottom sx={{ color: '#FF6F00', fontWeight: 'bold' }}>{tournament?.name}</Typography>
              <Typography variant="h6">Entry Fee: Free</Typography>
              <Typography variant="h6">Joined Players: {tournament?.players?.length || 0}</Typography>
              <Typography variant="h6">Start Time: 24x7 Instant Join</Typography>
              <Typography variant="h6">Prize: Top 10 Daily Winners</Typography>
              <Box sx={{ mt: 3 }}>
                <StyledButton onClick={handleOpenForm} disabled={isJoining}>
                    {isJoining ? 'Searching...' : 'Join Now'}
                </StyledButton>
              </Box>
            </CardContent>
          </StyledCard>
        </Grid>

        <Grid item xs={12} md={6}>
            <StyledCard>
                <CardContent>
                <Typography variant="h5" gutterBottom sx={{ color: '#FF6F00', fontWeight: 'bold' }}>Live Stats</Typography>
                <Typography>Participants: {tournament?.players?.length || 0}</Typography>
                <Typography>Matches Ongoing: {(tournament?.matches || []).filter(m => m.status === 'ongoing').length}</Typography>
                <Typography>Matches Completed: {(tournament?.matches || []).filter(m => m.status === 'completed').length}</Typography>
                </CardContent>
            </StyledCard>
        </Grid>

        <Grid item xs={12}>
           <PlayerStatus tournament={tournament} />
        </Grid>

        <Grid item xs={12}>
          <StyledCard>
            <CardContent>
              <Typography variant="h5" gutterBottom sx={{ color: '#FF6F00', fontWeight: 'bold' }}>Leaderboard</Typography>
              <TableContainer component={Paper} sx={{ background: 'transparent', color: 'white' }}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ color: 'white' }}>Rank</TableCell>
                      <TableCell sx={{ color: 'white' }}>Player</TableCell>
                      <TableCell sx={{ color: 'white' }} align="right">Points</TableCell>
                      <TableCell sx={{ color: 'white' }} align="right">Wins</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {leaderboard.map((player, index) => (
                      <TableRow key={index} sx={{ background: player.uid === currentUser?.uid ? 'rgba(255, 111, 0, 0.3)' : 'transparent' }}>
                        <TableCell sx={{ color: 'white' }}>{index + 1}</TableCell>
                        <TableCell sx={{ color: 'white' }}>{player.displayName}</TableCell>
                        <TableCell sx={{ color: 'white' }} align="right">{player.points}</TableCell>
                        <TableCell sx={{ color: 'white' }} align="right">{player.wins}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </StyledCard>
        </Grid>

        <Grid item xs={12}>
          <StyledCard>
            <CardContent>
              <Typography variant="h5" gutterBottom sx={{ color: '#FF6F00', fontWeight: 'bold' }}>Rules</Typography>
              <List>
                {rules.map((rule, index) => (
                  <ListItem key={index}>
                    <ListItemText primary={rule} />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </StyledCard>
        </Grid>
      </Grid>
    </Box>
  );
};

export default KnockoutTournament;
