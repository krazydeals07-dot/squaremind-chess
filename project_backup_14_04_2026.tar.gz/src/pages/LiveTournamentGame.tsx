import { useLayoutEffect, useRef, useMemo, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTournamentGame } from '../hooks/useTournamentGame';
import StyledChessboard from '../components/game/StyledChessboard';
import {
  Box,
  CircularProgress,
  Typography,
  Button,
  Grid,
  Paper,
  Avatar,
  Stack,
  Divider,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
} from '@mui/material';
import { Flag, Handshake, Check, Close } from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import CapturedPieces from '../components/CapturedPieces';
import Chat from '../components/game/Chat';
import { doc, updateDoc, arrayUnion } from 'firebase/firestore';
import { db } from '../firebase';

const PlayerInfoBox = ({ name, photoURL, timer, isCurrentUser, isTurn, gameStatus }: { name: string, photoURL?: string, timer: number, isCurrentUser?: boolean, isTurn?: boolean, gameStatus: string }) => {
    const displayTime = useMemo(() => {
        if (typeof timer !== 'number' || isNaN(timer) || timer < 0) return '00:00';
        const minutes = Math.floor(timer / 60);
        const seconds = Math.floor(timer % 60);
        return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }, [timer]);

    return (
        <Paper elevation={3} sx={{
            width: '100%',
            p: 1.5,
            background: isCurrentUser ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.2)',
            borderRadius: '12px',
            border: isTurn && gameStatus === 'active' ? '2px solid #FFD700' : (isCurrentUser ? '1px solid #777' : '1px solid #444'),
            boxShadow: isTurn && gameStatus === 'active' ? '0 0 12px rgba(255, 215, 0, 0.5)' : 'none',
            transition: 'all 0.3s ease-in-out'
        }}>
            <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="space-between">
                <Stack direction="row" spacing={1.5} alignItems="center">
                    <Avatar src={photoURL} sx={{ width: 40, height: 40, bgcolor: '#555' }} />
                    <Box>
                        <Typography variant="subtitle1" noWrap color="#e0e0e0" sx={{ fontWeight: 600 }}>{name || 'Player'}</Typography>
                        {isTurn && gameStatus === 'active' && (
                            <Typography sx={{ color: '#FFD700', fontWeight: 'bold', fontSize: '0.8rem' }}>Thinking...</Typography>
                        )}
                    </Box>
                </Stack>
                <Typography variant="h5" sx={{ fontFamily: 'monospace', background: '#111', color: isTurn ? '#FFD700' : '#e0e0e0', p: '4px 12px', borderRadius: 2 }}>
                    {displayTime}
                </Typography>
            </Stack>
        </Paper>
    );
};

const LiveTournamentGame = () => {
  const { gameId } = useParams<{ gameId: string }>();
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const { 
      game,
      gameData,
      timers,
      error,
      capturedBy,
      gameResult,
      isModalOpen,
      drawOffer,
      optionSquares,
      lastMoveSquares,
      onSquareClick,
      closeModal,
      resign,
      offerDraw,
      acceptDraw,
      declineDraw,
      isMyTurn,
      loading
  } = useTournamentGame(gameId!);

  const [boardWidth, setBoardWidth] = useState(500);
  const boardContainerRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const updateSize = () => {
      if (boardContainerRef.current) {
        const { width, height } = boardContainerRef.current.getBoundingClientRect();
        const newSize = Math.min(width * 0.9, height * 0.85, 560);
        setBoardWidth(Math.max(250, newSize));
      }
    };
    const resizeObserver = new ResizeObserver(updateSize);
    if (boardContainerRef.current) resizeObserver.observe(boardContainerRef.current);
    updateSize();
    return () => resizeObserver.disconnect();
  }, [gameData]);

  const orientation = useMemo(() => {
    if (!gameData || !currentUser) return 'white';
    return gameData.players.white === currentUser.uid ? 'white' : 'black';
  }, [gameData, currentUser]);

  const handleSendMessage = useCallback(async (message: string) => {
    if (message.trim() && gameId && currentUser) {
        await updateDoc(doc(db, 'games', gameId), { 
            chat: arrayUnion({ senderId: currentUser.uid, senderName: currentUser.displayName || 'Anonymous', message, timestamp: new Date() }) 
        });
    }
  }, [gameId, currentUser]);

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', background: '#1A1A2E' }}><CircularProgress color="warning" /></Box>;

  if (error || !gameData) return (
    <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', height: '100vh', background: '#1A1A2E', color: 'white' }}>
        <Typography variant="h5">{error || "Game could not be loaded."}</Typography>
        <Button variant="contained" onClick={() => navigate('/tournaments')} sx={{ mt: 2 }}>Back to Tournaments</Button>
    </Box>
  );

  const { playerNames, moves, status } = gameData;
  const opponentColor = orientation === 'white' ? 'b' : 'w';
  const myColor = orientation === 'white' ? 'w' : 'b';

  const opponentName = playerNames?.black && playerNames.white ? (orientation === 'white' ? playerNames.black : playerNames.white) : 'Waiting...';
  const myName = playerNames?.black && playerNames.white ? (orientation === 'white' ? playerNames.white : playerNames.black) : 'You';

  return (
    <Box sx={{ p: 0, m: 0, background: '#1A1A2E', minHeight: '100vh', color: 'white', display: 'flex', overflow: 'hidden'}}>
        <Grid container sx={{height: '100vh'}}>
            <Grid item xs={12} md={7} lg={8} ref={boardContainerRef} sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', p: { xs: 1, md: 2 }}}>
                <Stack direction="column" spacing={1} alignItems="center" sx={{ width: '100%', maxWidth: boardWidth }}>
                    <CapturedPieces title={`${opponentName}'s Captures`} pieces={capturedBy[myColor]} />
                    <StyledChessboard 
                        boardWidth={boardWidth} 
                        position={game.fen()} 
                        onSquareClick={onSquareClick} 
                        boardOrientation={orientation}
                        isDraggablePiece={({piece}) => isMyTurn && piece[0] === orientation[0]}
                        customSquareStyles={{...optionSquares, ...lastMoveSquares}}
                    />
                    <CapturedPieces title="Your Captures" pieces={capturedBy[opponentColor]} />
                </Stack>
            </Grid>

            <Grid item xs={12} md={5} lg={4} sx={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
                <Paper sx={{ p: 2, background: '#282C34', flexGrow: 1, display: 'flex', flexDirection: 'column', borderRadius: 0, overflowY: 'auto' }}>
                    <Typography variant="h5" align="center" sx={{ color: '#61DAFB', mb: 2, fontFamily: 'Orbitron' }}>Tournament Match</Typography>
                    <Stack spacing={1.5} sx={{ mb: 2 }}>
                        <PlayerInfoBox name={opponentName} timer={timers[opponentColor]} isTurn={!isMyTurn} gameStatus={status} />
                        <PlayerInfoBox name={myName} timer={timers[myColor]} isTurn={isMyTurn} isCurrentUser gameStatus={status} />
                    </Stack>
                    
                    {drawOffer && drawOffer.to === currentUser?.uid ? (
                        <Paper elevation={4} sx={{ p: 2, my: 1, background: '#4CAF50' }}>
                            <Typography align="center" sx={{ mb: 1 }}>{opponentName} offers a draw.</Typography>
                            <Stack direction="row" spacing={2} justifyContent="center">
                                <Button startIcon={<Check />} variant="contained" color="success" onClick={acceptDraw}>Accept</Button>
                                <Button startIcon={<Close />} variant="contained" color="error" onClick={declineDraw}>Decline</Button>
                            </Stack>
                        </Paper>
                    ) : (
                        <Stack direction="row" spacing={1} justifyContent="center" sx={{ my: 2 }}>
                            <Button startIcon={<Flag />} variant="contained" onClick={resign} disabled={status !== 'active'} sx={{ bgcolor: '#b71c1c', '&:hover': { bgcolor: '#9a1616' }, flexGrow:1 }}>
                                Resign
                            </Button>
                            <Button startIcon={<Handshake />} variant="contained" onClick={offerDraw} disabled={status !== 'active' || !!drawOffer} sx={{ bgcolor: '#0097a7', '&:hover': { bgcolor: '#007a8a' }, flexGrow:1 }}>
                                {drawOffer ? 'Draw Offered' : 'Offer Draw'}
                            </Button>
                        </Stack>
                    )}

                    <Divider sx={{ borderColor: '#555', my: 1 }} />
                    <Typography variant="overline" sx={{ color: '#999' }}>Move History</Typography>
                    <Box sx={{ height: '150px', overflowY: 'auto', background: '#1F2327', p: 1, mb: 2, borderRadius: '4px' }}>
                        <Grid container spacing={1}>
                            {moves?.map((m: any, i: number) => (
                                <Grid item xs={6} key={i}><Typography variant="body2" sx={{ color: '#ccc', fontFamily: 'monospace' }}>{i % 2 === 0 ? `${Math.floor(i/2)+1}.` : ''} {m.san}</Typography></Grid>
                            ))}
                        </Grid>
                    </Box>

                    <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column', background: '#1F2327', borderRadius: '8px', overflow: 'hidden' }}>
                        <Chat chat={gameData.chat || []} currentUser={currentUser} handleSendMessage={handleSendMessage} />
                    </Box>
                </Paper>
            </Grid>
        </Grid>

        <Dialog
            open={isModalOpen}
            onClose={closeModal}
            aria-labelledby="game-over-dialog-title"
            aria-describedby="game-over-dialog-description"
            PaperProps={{
                sx: {
                    background: '#282C34',
                    color: 'white',
                    borderRadius: '12px'
                }
            }}
        >
            <DialogTitle id="game-over-dialog-title" sx={{ color: '#61DAFB', fontFamily: 'Orbitron'}}>Game Over</DialogTitle>
            <DialogContent>
                <DialogContentText id="game-over-dialog-description" sx={{ color: '#e0e0e0'}}>
                    {gameResult}
                </DialogContentText>
            </DialogContent>
            <DialogActions>
                <Button onClick={closeModal} variant="contained" color="primary" autoFocus>
                    Close
                </Button>
            </DialogActions>
        </Dialog>
    </Box>
  );
};

export default LiveTournamentGame;
