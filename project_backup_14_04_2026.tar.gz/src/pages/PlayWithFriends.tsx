import React, { useState } from 'react';
import { Box, Button, TextField, Typography, Grid, Paper } from '@mui/material';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { collection, addDoc, serverTimestamp, doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import FriendLeaderboard from '../components/leaderboard/FriendLeaderboard';

const PlayWithFriends = () => {
    const [gameId, setGameId] = useState('');
    const { currentUser } = useAuth();
    const navigate = useNavigate();

    const createNewGame = async () => {
        if (!currentUser) return;
        const newGame = {
            players: {
                white: currentUser.uid,
                black: null,
            },
            fen: 'start',
            status: 'waiting',
            createdAt: serverTimestamp(),
        };
        const docRef = await addDoc(collection(db, 'games'), newGame);
        navigate(`/game/friends/${docRef.id}`);
    };

    const joinGame = async () => {
        if (!gameId) return;
        const gameRef = doc(db, 'games', gameId);
        const gameSnap = await getDoc(gameRef);
        if (gameSnap.exists()) {
            navigate(`/game/friends/${gameId}`);
        } else {
            alert('Game not found!');
        }
    };

    return (
        <Box sx={{ p: 3 }}>
             <Typography variant="h3" align="center" sx={{ mb: 4, fontFamily: '"Orbitron", sans-serif', color: '#FFA500'}}>
                Play with Friends
            </Typography>
            <Grid container spacing={4} justifyContent="center">
                <Grid item xs={12} md={5}>
                    <Paper sx={{ p: 3, background: 'rgba(0,0,0,0.3)', borderRadius: '12px' }}>
                        <Typography variant="h5" align="center" sx={{ mb: 2, fontFamily: '"Orbitron", sans-serif', color: 'white' }}>Lobby</Typography>
                        <Typography align="center" sx={{ mb: 2, color: 'lightgrey' }}>Create a new game and invite a friend.</Typography>
                        <Button fullWidth variant="contained" onClick={createNewGame} sx={{ mb: 2, background: 'linear-gradient(45deg, #FE6B8B 30%, #FF8E53 90%)', color: 'white', fontFamily: '"Orbitron", sans-serif' }}>Create New Game</Button>
                        <Typography align="center" sx={{ my: 2, color: 'lightgrey' }}>Or join a game using an ID.</Typography>
                        <TextField
                            fullWidth
                            variant="outlined"
                            placeholder="Enter Game ID"
                            value={gameId}
                            onChange={(e) => setGameId(e.target.value)}
                            sx={{ mb: 2, input: { color: 'white' }, fieldset: { borderColor: 'gray' } }}
                        />
                        <Button fullWidth variant="contained" onClick={joinGame} sx={{ background: 'linear-gradient(45deg, #8A2BE2 30%, #BA55D3 90%)', color: 'white', fontFamily: '"Orbitron", sans-serif' }}>Join Game</Button>
                    </Paper>
                </Grid>
                <Grid item xs={12} md={7}>
                    <FriendLeaderboard />
                </Grid>
            </Grid>
        </Box>
    );
};

export default PlayWithFriends;