import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, updateDoc, arrayUnion } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { Chess } from 'chess.js';
import { Chessboard } from 'react-chessboard';
import {
    Container, Paper, Box, CircularProgress, Grid, Typography, Button, Stack, Divider, List, ListItem, ListItemText, Avatar
} from '@mui/material';
import { usePlayFriends } from '../hooks/usePlayFriends';
import { useTournamentGame } from '../hooks/useTournamentGame';
import { UserProfile, GameData } from '../types';
import GameInfo from '../components/game/GameInfo';
import Chat from '../components/game/Chat';
import GameOverModal from '../components/game/GameOverModal';
import PieceRenderer from '../components/game/PieceRenderer';
import CapturedPieces from '../components/CapturedPieces';

const PlayerInfoBox = ({ name, photoURL, timer, isCurrentUser, isTurn, gameStatus }: { name: string, photoURL?: string, timer: number, isCurrentUser?: boolean, isTurn?: boolean, gameStatus: string }) => (
    <Box sx={{
        width: '100%',
        p: 2,
        background: isCurrentUser ? '#4a3f2b' : '#201d2d',
        borderRadius: '8px',
        border: isCurrentUser ? '1px solid #c9a35e' : '1px solid #201d2d',
        transition: 'all 0.3s ease'
    }}>
        <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="space-between">
            <Stack direction="row" spacing={1.5} alignItems="center">
                <Avatar src={photoURL} sx={{ width: 40, height: 40, bgcolor: '#444' }} />
                <Typography variant="subtitle1" noWrap color="#e0e0e0">{name || 'Opponent'}</Typography>
                {isTurn && gameStatus === 'active' && <Typography sx={{ color: '#66bb6a', fontWeight: 'bold', ml: 1.5 }}>Your Turn</Typography>}
            </Stack>
            <Typography variant="h5" sx={{ fontFamily: 'monospace', background: '#1a1a1a', color: '#e0e0e0', p: '4px 12px', borderRadius: 1 }}>
                {timer ? `${Math.floor(timer / 60)}:${String(timer % 60).padStart(2, '0')}` : '-'}
            </Typography>
        </Stack>
    </Box>
  );

const GameRoom = () => {
    const { gameId } = useParams<{ gameId: string }>();
    const [gameData, setGameData] = useState<GameData | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchGameData = async () => {
            const gameDoc = await getDoc(doc(db, 'games', gameId!));
            if (gameDoc.exists()) {
                setGameData(gameDoc.data() as GameData);
            }
            setLoading(false);
        };
        fetchGameData();
    }, [gameId]);

    if (loading) {
        return <Container sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}><CircularProgress /></Container>;
    }

    if (!gameData) {
        return <Typography>Game not found</Typography>;
    }

    return gameData.tournamentId ? <TournamentGame gameData={gameData} /> : <FriendlyGame gameData={gameData} />;
};

const FriendlyGame = ({ gameData: initialGameData }: { gameData: GameData }) => {
    const { gameId } = useParams<{ gameId: string }>();
    const { currentUser } = useAuth();
    const navigate = useNavigate();

    const {
        game,
        gameData,
        capturedBy,
        gameResult,
        isModalOpen,
        onSquareClick,
        optionSquares,
        closeModal,
        boardOrientation,
        startNewGame,
    } = usePlayFriends(gameId!, initialGameData)

    const [opponentProfile, setOpponentProfile] = useState<UserProfile | null>(null);
    const [boardWidth, setBoardWidth] = useState(560);
    const chessboardContainerRef = useRef<HTMLDivElement>(null);

    const opponentId = useMemo(() => {
        if (!gameData || !currentUser) return null;
        return gameData.players.white === currentUser.uid ? gameData.players.black : gameData.players.white;
    }, [gameData?.players, currentUser]);

    useEffect(() => {
        const handleResize = () => {
            if (chessboardContainerRef.current) {
                setBoardWidth(chessboardContainerRef.current.offsetWidth);
            }
        };
        window.addEventListener('resize', handleResize);
        handleResize();
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    useEffect(() => {
        let isMounted = true;
        if (opponentId) {
            getDoc(doc(db, 'users', opponentId)).then(userDoc => {
                if (isMounted && userDoc.exists()) {
                    setOpponentProfile({ ...userDoc.data(), uid: opponentId } as UserProfile);
                }
            });
        } else {
            if (isMounted) setOpponentProfile(null);
        }
        return () => { isMounted = false; };
    }, [opponentId]);
    
    const handleSendMessage = useCallback(async (message: string) => {
        if (message.trim() && gameId && currentUser) {
            await updateDoc(doc(db, 'games', gameId), { chat: arrayUnion({ senderId: currentUser.uid, senderName: currentUser.displayName || 'Anonymous', message, timestamp: new Date() }) });
        }
    }, [gameId, currentUser]);

    const handleGoBack = useCallback(() => {
        navigate('/play/friends');
    }, [navigate]);

    if (!gameData || !currentUser) {
        return <Container sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}><CircularProgress /></Container>;
    }

    const displayOpponent = opponentProfile || { displayName: 'Waiting...', photoURL: '', uid: 'placeholder' };

    const isMyTurn = (game.turn() === 'w' && gameData?.players?.white === currentUser.uid) || (game.turn() === 'b' && gameData?.players?.black === currentUser.uid);
    const gameStatus = !opponentId || gameData.status === 'waiting' 
        ? 'Waiting for opponent...' 
        : game.isGameOver() 
        ? 'Game Over' 
        : isMyTurn 
        ? "Your Turn" 
        : `${displayOpponent.displayName}’s Turn`;

    const yourColor = boardOrientation === 'white' ? 'white' : 'black';
    const opponentColor = boardOrientation === 'white' ? 'black' : 'white';

    return (
        <Box sx={{ p: { xs: 1, sm: 2 } }}>
            <Grid container spacing={2} justifyContent="center" alignItems="flex-start">
                <Grid item xs={12} md={8} sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <Box sx={{ width: '100%', maxWidth: '560px' }}>
                        <CapturedPieces title={`${displayOpponent.displayName} Captures`} pieces={capturedBy[opponentColor]} />
                        <Paper ref={chessboardContainerRef} elevation={10} sx={{ background: 'transparent', width: '100%' }}>
                            <Chessboard position={game.fen()} arePiecesDraggable={true} onSquareClick={onSquareClick} customSquareStyles={optionSquares} boardWidth={boardWidth} boardOrientation={boardOrientation} customPieces={PieceRenderer} customBoardStyle={{ borderRadius: '8px', boxShadow: '0 5px 15px rgba(0, 0, 0, 0.5)' }} customDarkSquareStyle={{ backgroundColor: '#6B3F23' }} customLightSquareStyle={{ backgroundColor: '#EAD8C3' }} />
                        </Paper>
                        <CapturedPieces title="Your Captures" pieces={capturedBy[yourColor]} />
                    </Box>
                </Grid>

                <Grid item xs={12} md={4}>
                    <Paper elevation={10} sx={{ p: 3, background: 'rgba(30, 30, 40, 0.85)', backdropFilter: 'blur(10px)', borderRadius: '15px', color: 'white' }}>
                       <GameInfo isTournamentGame={false} currentUser={currentUser} opponentProfile={displayOpponent} isMyTurn={isMyTurn} gameStatus={gameStatus} />
                    </Paper>
                    <Paper sx={{ p: 2, mt: 3, background: 'rgba(30, 30, 40, 0.85)', backdropFilter: 'blur(10px)', borderRadius: '15px', color: 'white', height: '300px', display: 'flex', flexDirection: 'column' }}>
                        <Chat chat={gameData.chat || []} currentUser={currentUser} handleSendMessage={handleSendMessage} />
                    </Paper>
                </Grid>
            </Grid>

            <GameOverModal isOpen={isModalOpen} onClose={closeModal} gameResult={gameResult} isTournamentGame={false} handleGoBack={handleGoBack} startNewGame={startNewGame} />
        </Box>
    );
};

const TournamentGame = ({ gameData: initialGameData }: { gameData: GameData }) => {
    const { gameId } = useParams<{ gameId: string }>();
    const { currentUser } = useAuth();
    const navigate = useNavigate();

    const { 
        game, 
        gameData, 
        timers, 
        error, 
        capturedBy, 
        gameResult, 
        isModalOpen, 
        drawOffer, 
        optionSquares, 
        lastMoveSquares, 
        onSquareClick, 
        closeModal, 
        resign, 
        offerDraw, 
        acceptDraw, 
        declineDraw, 
        isMyTurn 
    } = useTournamentGame(gameId!, initialGameData);

    const [boardWidth, setBoardWidth] = useState(500);
    const chessboardRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        function updateSize() {
          if (chessboardRef.current) {
              const containerWidth = chessboardRef.current.offsetWidth;
              const containerHeight = window.innerHeight - 200;
              setBoardWidth(Math.min(containerWidth, containerHeight, 700));
          }
        }
        window.addEventListener('resize', updateSize);
        updateSize();
        return () => window.removeEventListener('resize', updateSize);
      }, []);

    const orientation = useMemo(() => {
        if (!gameData || !currentUser) return 'white';
        return gameData.players.white === currentUser.uid ? 'white' : 'black';
    }, [gameData, currentUser]);

    if (error) {
        return (
            <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', height: '100vh', background: '#201d2d', color: 'white' }}>
                <Typography variant="h5" gutterBottom>{error}</Typography>
                <Button variant="contained" onClick={() => navigate('/tournaments')}>Back to Tournaments</Button>
            </Box>
        );
    }

    if (!gameData || !gameData.playerNames) {
        return <Container sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}><CircularProgress /></Container>;
    }

    const { playerNames, moves, status } = gameData;
    const whitePlayerName = playerNames.white || 'Waiting for opponent...';
    const blackPlayerName = playerNames.black || 'Player';

    const opponentPlayerName = orientation === 'white' ? blackPlayerName : whitePlayerName;
    const currentPlayerName = orientation === 'white' ? whitePlayerName : blackPlayerName;
    const opponentColor = orientation === 'white' ? 'b' : 'w';
    const yourColor = orientation === 'white' ? 'w' : 'b';

    return (
        <Box sx={{ p: { xs: 1, sm: 2 } }}>
            <Grid container spacing={2} justifyContent="center" alignItems="flex-start">
                <Grid item xs={12} md={8} sx={{display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}} ref={chessboardRef}>
                    <CapturedPieces title={`${opponentPlayerName} Captures`} pieces={capturedBy[opponentColor]} />
                    <Paper elevation={10} sx={{ p: { xs: 1, sm: 2 }, background: '#2c2a3a', borderRadius: '15px', display: 'inline-block' }}>
                        <Chessboard 
                            boardWidth={boardWidth} 
                            position={game.fen()} 
                            onSquareClick={onSquareClick} 
                            boardOrientation={orientation} 
                            customBoardStyle={{ borderRadius: '8px', boxShadow: '0 5px 15px rgba(0, 0, 0, 0.5)' }} 
                            customDarkSquareStyle={{ backgroundColor: '#764f3a' }} 
                            customLightSquareStyle={{ backgroundColor: '#e9d9b9' }} 
                            customSquareStyles={{...optionSquares, ...lastMoveSquares}}
                            isDraggablePiece={({piece}) => piece[0] === orientation[0]}
                        />
                    </Paper>
                    <CapturedPieces title="Your Captures" pieces={capturedBy[yourColor]} />
                </Grid>

                <Grid item xs={12} md={4}>
                    <Paper sx={{ p: 2, background: '#2c2a3a', height: '100%', display: 'flex', flexDirection: 'column' }}>
                        <Typography variant="h5" align="center" gutterBottom sx={{ fontFamily: '"Orbitron", sans-serif', color: '#33C3FF' }}>
                            Tournament Match
                        </Typography>
                       
                        <Stack spacing={2} sx={{my: 2}}>
                            <PlayerInfoBox name={opponentPlayerName} timer={timers[opponentColor.charAt(0)]} isTurn={!isMyTurn} gameStatus={status} />
                            <PlayerInfoBox name={currentPlayerName} timer={timers[yourColor.charAt(0)]} isCurrentUser={true} isTurn={isMyTurn} gameStatus={status} />
                        </Stack>
                       
                        <Divider sx={{ borderColor: '#444', my: 1 }} />

                        <Typography variant="h6" sx={{mt: 2, mb: 1, color: '#9e9e9e'}}>Move History</Typography>
                        <Box sx={{ flexGrow: 1, overflowY: 'auto', background: '#201d2d', borderRadius: 2, p: 1, minHeight: '150px' }}>
                            <List dense>
                               {moves?.map((move: any, index: number) => (
                                    <ListItem key={index} sx={{ py: 0.2, my: 0 }}>
                                        <ListItemText primary={`${Math.floor(index / 2) + 1}. ${move.san}`} primaryTypographyProps={{ style: { color: '#b0b0b0', fontSize: '0.9rem' } }} />
                                    </ListItem>
                                ))}
                            </List>
                        </Box>
                       
                        <Stack direction="row" spacing={2} sx={{ mt: 'auto', pt: 2 }}>
                            {drawOffer && drawOffer.to === currentUser?.uid ? (
                                <>
                                    <Button variant="contained" onClick={acceptDraw}>Accept Draw</Button>
                                    <Button variant="outlined" onClick={declineDraw}>Decline</Button>
                                </>
                            ) : (
                                <>
                                    <Button variant="contained" onClick={resign} disabled={status !== 'active'}>Resign</Button>
                                    <Button variant="contained" onClick={offerDraw} disabled={status !== 'active' || !!drawOffer}>{drawOffer ? "Draw Offered" : "Offer Draw"}</Button>
                                </>
                            )}
                        </Stack>
                    </Paper>
                </Grid>
            </Grid>
            {isModalOpen && (
                <GameOverModal isOpen={isModalOpen} onClose={closeModal} gameResult={{message: gameResult, result: 'win'}} isTournamentGame={true} handleGoBack={() => navigate(`/tournaments/${gameData.tournamentId}`)} />
            )}
        </Box>
    );
};

export default GameRoom;