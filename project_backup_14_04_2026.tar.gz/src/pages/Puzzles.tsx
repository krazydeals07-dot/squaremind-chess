import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Paper,
  Box,
  Grid,
  Badge,
  Button,
  ButtonGroup,
  useTheme,
  useMediaQuery
} from '@mui/material';
import { puzzles, dailyPuzzleId } from '../data/puzzles';
import PuzzleDisplay from '../components/puzzles/Puzzle';
import QASession from '../components/puzzles/QASession';
import { useAuth } from '../contexts/AuthContext';
import { doc, getDoc, setDoc, updateDoc, increment } from 'firebase/firestore';
import { db } from '../firebase';
import ChessIcon from '../components/ChessIcon';

type View = 'daily' | 'practice' | 'qa';

interface UserStats {
  score: number;
  streak: number;
  puzzlesSolved: number[];
  lastSolved: string;
}

const Puzzles = () => {
  const { currentUser, isGuest } = useAuth();
  const [userStats, setUserStats] = useState<UserStats>({
    score: 0,
    streak: 0,
    puzzlesSolved: [],
    lastSolved: ''
  });
  const [view, setView] = useState<View>('daily');

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const dailyPuzzle = puzzles.find(p => p.id === dailyPuzzleId);
  const otherPuzzles = puzzles.filter(p => p.id !== dailyPuzzleId);

  useEffect(() => {
    if (currentUser && !isGuest) {
      const fetchUserStats = async () => {
        const ref = doc(db, 'userPuzzles', currentUser.uid);
        const snap = await getDoc(ref);
        if (snap.exists()) {
          setUserStats(snap.data() as UserStats);
        } else {
          await setDoc(ref, {
            score: 0,
            streak: 0,
            puzzlesSolved: [],
            lastSolved: ''
          });
        }
      };
      fetchUserStats();
    }
  }, [currentUser, isGuest]);

  const handleSolve = async (points: number, puzzleId: number) => {
    if (userStats.puzzlesSolved.includes(puzzleId)) return;

    if (isGuest) {
      setUserStats(prev => ({
        ...prev,
        score: prev.score + points,
        puzzlesSolved: [...prev.puzzlesSolved, puzzleId]
      }));
      return;
    }

    if (!currentUser) return;

    const ref = doc(db, 'userPuzzles', currentUser.uid);
    const today = new Date().toDateString();

    await updateDoc(ref, {
      score: increment(points),
      puzzlesSolved: [...userStats.puzzlesSolved, puzzleId],
      lastSolved: today
    });

    const snap = await getDoc(ref);
    if (snap.exists()) setUserStats(snap.data() as UserStats);
  };

  const renderView = () => {
    switch (view) {
      case 'daily':
        return dailyPuzzle ? (
          <Box mt={4} display="flex" justifyContent="center">
            <PuzzleDisplay
              puzzle={dailyPuzzle}
              onSolve={(p) => handleSolve(p, dailyPuzzle.id)}
              isGuest={isGuest}
            />
          </Box>
        ) : null;

      case 'practice':
        return (
          <Grid container spacing={2}>
            {otherPuzzles.map(p => (
              <Grid item xs={12} sm={6} md={4} key={p.id}>
                <PuzzleDisplay
                  puzzle={p}
                  onSolve={(pts) => handleSolve(pts, p.id)}
                  isGuest={isGuest}
                />
              </Grid>
            ))}
          </Grid>
        );

      case 'qa':
        return <QASession />;

      default:
        return null;
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: { xs: 2, md: 4 } }}>
      <Paper elevation={12} sx={{ p: {xs: 2, md: 3}, background: 'rgba(15, 15, 25, 0.8)', backdropFilter: 'blur(12px)', borderRadius: '20px', color: 'white' }}>
        <Box sx={{ textAlign: 'center', mb: 2 }}>
            <ChessIcon />
            <Typography variant={isMobile ? "h5" : "h4"} sx={{ fontFamily: 'Orbitron', fontWeight: 'bold', textTransform: 'uppercase', color: 'orange', whiteSpace: 'nowrap' }}>
                Puzzles & Training
            </Typography>
        </Box>

        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', mb: 2, flexDirection: 'column' }}>
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h6">Score: {userStats.score}</Typography>
            {!isGuest && (
              <>
                <Box sx={{display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Typography variant="subtitle1">Streak: {userStats.streak} days</Typography>
                    <Badge badgeContent={`🔥`} color="error" sx={{ml: 1}}/>
                </Box>
              </>
            )}
          </Box>
        </Box>

        <ButtonGroup 
            variant="contained" 
            fullWidth 
            sx={{ mb: 3 }} 
            orientation={isMobile ? 'vertical' : 'horizontal'}
        >
            <Button onClick={() => setView('daily')} color={view === 'daily' ? 'primary' : 'inherit'}>Puzzle of the Day</Button>
            <Button onClick={() => setView('practice')} color={view === 'practice' ? 'primary' : 'inherit'}>Practice Puzzles</Button>
            <Button onClick={() => setView('qa')} color={view === 'qa' ? 'primary' : 'inherit'}>Q&A</Button>
        </ButtonGroup>

        {renderView()}

      </Paper>
    </Container>
  );
};

export default Puzzles;
