import React, { useState, useEffect, useMemo } from 'react';
import { Box, Typography, Grid, Paper, CircularProgress, Container } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import { SportsEsports, Event } from '@mui/icons-material';
import { getTournamentsRT, Tournament } from '../utils/firebase/tournaments';
import ChessIcon from '../components/ChessIcon';

const categoryStyles = {
    paper: {
        padding: { xs: '1.5rem', md: '2rem' },
        textAlign: 'center',
        borderRadius: '20px',
        color: '#fff',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
        textDecoration: 'none',
        '&:hover': {
            transform: 'translateY(-10px)',
            boxShadow: '0 15px 25px rgba(0,0,0,0.3)',
        },
    },
    icon: {
        fontSize: '3.5rem',
        marginBottom: '1rem',
    },
    title: {
        fontWeight: 'bold',
        fontSize: '1.6rem',
        textTransform: 'uppercase',
    },
    count: {
        fontSize: '1rem',
        marginTop: '0.5rem',
        opacity: 0.9,
        fontWeight: '500',
    },
};

const Tournaments = () => {
    const [tournaments, setTournaments] = useState<Tournament[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const unsubscribe = getTournamentsRT(
            (data) => {
                setTournaments(data);
                setLoading(false);
            },
            (err) => {
                console.error(err);
                setLoading(false);
            }
        );
        return () => unsubscribe();
    }, []);

    const categories = useMemo(() => {
        const upcomingCount = tournaments.filter(t => t.status === 'upcoming').length;
        const knockoutCount = tournaments.filter(t => 
            t.type?.toLowerCase().includes('knockout') || 
            t.type?.toLowerCase().includes('elimination')
        ).length;

        return { upcoming: upcomingCount, knockout: knockoutCount };
    }, [tournaments]);

    if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60vh' }}><CircularProgress /></Box>;

    return (
        <Box sx={{ 
            py: 0, 
            mt: -4, // Pulled up more to clear space for footer
            background: '#0F172A', 
            minHeight: 'calc(100vh - 180px)', // Adjusted height
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            overflow: 'hidden'
        }}>
            <Container maxWidth="lg">
                <Box sx={{ mb: 0.5, textAlign: 'center', '& svg': { width: 60, height: 60 } }}>
                    <ChessIcon />
                </Box>
                
                 <Typography 
                    variant="h4" 
                    align="center" 
                    sx={{ 
                        mb: 0, 
                        fontWeight: 'bold', 
                        fontFamily: 'Orbitron, sans-serif',
                        color: '#F59E0B',
                        fontSize: '2.2rem'
                    }}
                >
                    TOURNAMENT HUB
                </Typography>
                <Typography 
                    variant="body1" 
                    align="center"
                    sx={{ mb: 3, color: '#94A3B8', fontWeight: 'normal' }}
                >
                    Compete, Win, and Rise to the Top!
                </Typography>

                <Grid container spacing={4} justifyContent="center">
                    {/* Knockout Category */}
                    <Grid item xs={12} sm={6} md={5}>
                        <Paper 
                            component={RouterLink} 
                            to="/tournaments/knockout" 
                            elevation={10} 
                            sx={{ ...categoryStyles.paper, background: 'linear-gradient(135deg, #EA580C 0%, #F59E0B 100%)' }}
                        >
                            <SportsEsports sx={categoryStyles.icon} />
                            <Typography sx={categoryStyles.title}>KNOCKOUT TOURNAMENTS</Typography>
                            <Typography sx={categoryStyles.count}>{categories.knockout} tournaments</Typography>
                        </Paper>
                    </Grid>

                    {/* Upcoming Challenges Category */}
                    <Grid item xs={12} sm={6} md={5}>
                        <Paper 
                            component={RouterLink} 
                            to="/tournaments/upcoming" 
                            elevation={10} 
                            sx={{ ...categoryStyles.paper, background: 'linear-gradient(135deg, #2563EB 0%, #0EA5E9 100%)' }}
                        >
                            <Event sx={categoryStyles.icon} />
                            <Typography sx={categoryStyles.title}>UPCOMING CHALLENGES</Typography>
                            <Typography sx={categoryStyles.count}>{categories.upcoming} tournaments</Typography>
                        </Paper>
                    </Grid>
                </Grid>
            </Container>
        </Box>
    );
};

export default Tournaments;
