
import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { doc, onSnapshot, updateDoc, arrayUnion, collection, getDocs, query, orderBy, writeBatch } from 'firebase/firestore';
import { db, functions } from '../firebase';
import { httpsCallable } from 'firebase/functions';
import { useAuth } from '../contexts/AuthContext';
import { Tournament, Match } from '../types/tournament';
import { Box, Button, Container, Typography, Paper, Grid, CircularProgress, Alert, Stack, Chip } from '@mui/material';
import { styled } from '@mui/system';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';

const LobbyContainer = styled(Container)(({ theme }) => ({
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4),
}));

const TournamentPaper = styled(Paper)(({ theme }) => ({
    padding: theme.spacing(3),
    background: 'linear-gradient(145deg, #2c3e50, #34495e)',
    color: '#ecf0f1',
    borderRadius: '15px',
}));

const startTournamentFn = httpsCallable(functions, 'startTournament');

const TournamentLobby = () => {
    const { tournamentId } = useParams<{ tournamentId: string }>();
    const { currentUser, isAdmin } = useAuth();
    const navigate = useNavigate();

    const [tournament, setTournament] = useState<Tournament | null>(null);
    const [matches, setMatches] = useState<Match[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isRegistered, setIsRegistered] = useState(false);
    const [isProcessing, setIsProcessing] = useState(false);

    useEffect(() => {
        if (!tournamentId) return;
        setLoading(true);

        const tournamentRef = doc(db, 'tournaments', tournamentId);
        const unsubscribeTournament = onSnapshot(tournamentRef, (docSnap) => {
            if (docSnap.exists()) {
                const tourneyData = docSnap.data() as Tournament;
                setTournament(tourneyData);
                setIsRegistered(currentUser ? tourneyData.registeredPlayers?.some(p => p.uid === currentUser.uid) || false : false);
            } else {
                setError("Tournament not found.");
            }
            setLoading(false);
        });

        const matchesRef = collection(db, 'tournaments', tournamentId, 'matches');
        const q = query(matchesRef, orderBy("round"), orderBy("matchIndex"));
        const unsubscribeMatches = onSnapshot(q, (snapshot) => {
            const matchesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Match));
            setMatches(matchesData);
        });

        return () => {
            unsubscribeTournament();
            unsubscribeMatches();
        };
    }, [tournamentId, currentUser]);

    const handleRegister = async () => {
        if (!currentUser || !tournamentId) return;
        setIsProcessing(true);
        try {
            const tournamentRef = doc(db, "tournaments", tournamentId);
            await updateDoc(tournamentRef, { 
                registeredPlayers: arrayUnion({ 
                    uid: currentUser.uid, 
                    displayName: currentUser.displayName 
                }) 
            });
        } catch (e) {
            setError("Failed to register.");
        } finally {
            setIsProcessing(false);
        }
    };

    const handleStartTournament = async () => {
        if (!tournamentId) return;
        setIsProcessing(true);
        try {
            await startTournamentFn({ tournamentId });
        } catch (e) {
            setError("Failed to start tournament. Check logs.");
        } finally {
            setIsProcessing(false);
        }
    };

    const handleResetTournament = async () => {
        if (!tournamentId) return;
        setIsProcessing(true);
        setError(null);

        try {
            const batch = writeBatch(db);
            const tournamentRef = doc(db, "tournaments", tournamentId);

            // Get all matches to find their associated game IDs
            const matchesSnapshot = await getDocs(collection(db, "tournaments", tournamentId, "matches"));

            if (!matchesSnapshot.empty) {
                matchesSnapshot.forEach(matchDoc => {
                    const matchData = matchDoc.data();
                    // Delete the match document
                    batch.delete(matchDoc.ref);

                    // If the match has a gameId, delete the corresponding game document
                    if (matchData.gameId) {
                        const gameRef = doc(db, "games", matchData.gameId);
                        batch.delete(gameRef);
                    }
                });
            }

            // Reset the tournament's players list and status
            batch.update(tournamentRef, { registeredPlayers: [], status: 'registration' });

            // Commit the entire batch operation
            await batch.commit();

            // Clear local state to reflect the reset
            setMatches([]);
            setIsRegistered(false);
            alert("Tournament has been reset successfully!");

        } catch (e: any) {
            console.error("Failed to reset tournament:", e);
            setError(`Failed to reset tournament: ${e.message}`);
            alert(`Error resetting tournament: ${e.message}`);
        } finally {
            setIsProcessing(false);
        }
    };

    const handleNavigateToGame = (gameId: string) => {
        navigate(`/tournaments/${tournamentId}/game/${gameId}`);
    };

    if (loading) return <CircularProgress sx={{ display: 'block', margin: 'auto', mt: 5 }} />;
    if (error) return <Alert severity="error">{error}</Alert>;
    if (!tournament) return <Typography>No tournament data available.</Typography>;

    const myCurrentMatch = matches.find(m => m.status === 'ongoing' && (m.player1?.uid === currentUser?.uid || m.player2?.uid === currentUser?.uid));

    return (
        <LobbyContainer>
            <TournamentPaper elevation={10}>
                <Box textAlign="center" mb={3}>
                    <EmojiEventsIcon sx={{ fontSize: 60, color: '#f1c40f' }} />
                    <Typography variant="h3" gutterBottom>{tournament.name}</Typography>
                    <Chip label={`Status: ${tournament.status}`} color={tournament.status === 'ongoing' ? 'success' : 'default'} />
                </Box>

                {isAdmin && (
                    <Stack direction="row" spacing={2} justifyContent="center" my={2}>
                        {tournament.status === 'registration' && (
                             <Button variant="contained" color="primary" onClick={handleStartTournament} disabled={isProcessing || (tournament.registeredPlayers?.length || 0) < 2}>
                                {isProcessing ? <CircularProgress size={24} /> : `Start Tournament (${tournament.registeredPlayers?.length || 0} Players)`}
                            </Button>
                        )}
                        <Button variant="outlined" color="warning" onClick={handleResetTournament} disabled={isProcessing}>
                           {isProcessing ? <CircularProgress size={24} /> : 'Reset Tournament'}
                        </Button>
                    </Stack>
                )}

                {tournament.status === 'registration' && !isAdmin && (
                    <Box textAlign="center" my={4}>
                        {isRegistered ? (
                            <Typography variant="h5" color="#2ecc71">You are registered!</Typography>
                        ) : (
                            <Button variant="contained" color="success" size="large" onClick={handleRegister} disabled={isProcessing}>
                                Register Now
                            </Button>
                        )}
                    </Box>
                )}

                {myCurrentMatch && (
                    <Box textAlign="center" my={4}>
                        <Alert severity="info">You have a live match!</Alert>
                        <Button variant="contained" color="primary" size="large" sx={{ mt: 2 }} onClick={() => handleNavigateToGame(myCurrentMatch.gameId!)}>
                            Go to Your Game
                        </Button>
                    </Box>
                )}

                <Typography variant="h5" mt={4} mb={2}>Bracket</Typography>
                <Grid container spacing={2}>
                    {matches.map(match => (
                        <Grid item xs={12} sm={6} md={4} key={match.id}>
                            <Paper sx={{ p: 2, background: '#34495e', borderLeft: `5px solid ${match.status === 'ongoing' ? '#2ecc71' : match.status === 'completed' ? '#f1c40f' : '#95a5a6'}` }}>
                                <Typography>R{match.round} - M{match.matchIndex}</Typography>
                                <Typography>P1: {match.player1?.displayName || 'TBD'} {match.winner?.uid === match.player1?.uid ? '👑' : ''}</Typography>
                                <Typography>P2: {match.player2?.displayName || 'TBD'} {match.winner?.uid === match.player2?.uid ? '👑' : ''}</Typography>
                                {myCurrentMatch?.id === match.id && (
                                    <Button size="small" variant='contained' onClick={() => handleNavigateToGame(match.gameId!)} sx={{ mt: 1 }}>Join</Button>
                                )}
                            </Paper>
                        </Grid>
                    ))}
                </Grid>

            </TournamentPaper>
        </LobbyContainer>
    );
};

export default TournamentLobby;
