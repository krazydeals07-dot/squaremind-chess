import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
    Box, Button, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle, Grid,
    Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField,
    Typography, Alert, FormControl, InputLabel, Select, MenuItem, Chip, IconButton, Accordion, AccordionSummary, AccordionDetails
} from '@mui/material';
import { Edit, Delete, Add, ExpandMore, Visibility, Refresh, Settings as SettingsIcon } from '@mui/icons-material';
import {
    getTournamentsRT, createTournament, updateTournament, deleteTournament, generateBracket, Tournament, getTournamentDoc, createTournamentWithId, generateNextRound, resetBracket
} from '../../utils/firebase/tournaments';
import { collection, getDocs, Timestamp } from 'firebase/firestore';
import { db } from '../../firebase';
import PropTypes from 'prop-types';
import BracketView from '../../components/admin/BracketView';

interface TournamentType {
    id: string;
    name: string;
    maxPlayers: number;
    rounds: number;
    entryFee: number;
    prizePool: string;
    timeControl: number;
    increment: number;
}

const isValidDate = (d: any) => d instanceof Date && !isNaN(d.getTime());

const TournamentTable = ({ tournaments, onEdit, onDelete, onGenerateBracket, onManageBracket, onResetBracket }) => {
    return (
        <TableContainer component={Paper} sx={{ mb: 4, borderRadius: '12px' }}>
            <Table>
                <TableHead sx={{ bgcolor: '#f8f9fa' }}>
                    <TableRow>
                        <TableCell sx={{ fontWeight: 'bold' }}>Name</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Type</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Players</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Time Control</TableCell>
                        <TableCell sx={{ fontWeight: 'bold' }}>Status</TableCell>
                        <TableCell align="right" sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {tournaments.map((tournament) => {
                        return (
                            <TableRow key={tournament.id} hover>
                                <TableCell sx={{ fontWeight: 600 }}>{tournament.name}</TableCell>
                                <TableCell>{tournament.type}</TableCell>
                                <TableCell>{`${tournament.players?.length || 0} / ${tournament.maxPlayers || '∞'}`}</TableCell>
                                <TableCell>{tournament.timeControl ? `${tournament.timeControl} + ${tournament.increment || 0}` : 'N/A'}</TableCell>
                                <TableCell>
                                    <Chip 
                                        label={tournament.status} 
                                        size="small"
                                        color={tournament.status === 'ongoing' ? 'success' : tournament.status === 'upcoming' ? 'primary' : 'default'} 
                                    />
                                </TableCell>
                                <TableCell align="right">
                                    <IconButton size="small" onClick={() => onEdit(tournament)} color="primary"><Edit /></IconButton>
                                    <IconButton size="small" color="error" onClick={() => onDelete(tournament.id)}><Delete /></IconButton>
                                    {tournament.status === 'upcoming' && (
                                        <Button size="small" variant="outlined" sx={{ ml: 1 }} onClick={() => onGenerateBracket(tournament.id)}>Start</Button>
                                    )}
                                    {tournament.status === 'ongoing' && (
                                        <IconButton size="small" color="secondary" onClick={() => onManageBracket(tournament)} sx={{ ml: 1 }}><Visibility /></IconButton>
                                    )}
                                </TableCell>
                            </TableRow>
                        );
                    })}
                </TableBody>
            </Table>
        </TableContainer>
    );
};

const TournamentManagement: React.FC = () => {
    const [tournaments, setTournaments] = useState<Tournament[]>([]);
    const [tournamentTypes, setTournamentTypes] = useState<TournamentType[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [formOpen, setFormOpen] = useState(false);
    const [bracketOpen, setBracketOpen] = useState(false);
    const [currentTournament, setCurrentTournament] = useState<any>(null);
    const [selectedTournamentForBracket, setSelectedTournamentForBracket] = useState<Tournament | null>(null);
    const [isNew, setIsNew] = useState(false);

    const fetchTournamentTypes = useCallback(async () => {
        try {
            const colRef = collection(db, 'tournamentTypes');
            const snapshot = await getDocs(colRef);
            const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as TournamentType));
            setTournamentTypes(data);
        } catch (err) {
            console.error("Error fetching types:", err);
        }
    }, []);

    useEffect(() => {
        fetchTournamentTypes();
        const unsubscribe = getTournamentsRT(data => {
            setTournaments(data);
            setLoading(false);
        }, (err) => {
            setError('Failed to load tournaments.');
            setLoading(false);
        });
        return () => unsubscribe();
    }, [fetchTournamentTypes]);

    const handleOpenForm = (tournament: any = null) => {
        if (tournament) {
            setCurrentTournament({
                ...tournament,
                startDate: tournament.startDate?.toDate ? tournament.startDate.toDate().toISOString().substring(0, 16) : new Date().toISOString().substring(0, 16),
                endDate: tournament.endDate?.toDate ? tournament.endDate.toDate().toISOString().substring(0, 16) : new Date().toISOString().substring(0, 16),
            });
            setIsNew(false);
        } else {
            setIsNew(true);
            setCurrentTournament({
                name: '',
                type: '',
                maxPlayers: 32,
                rounds: 5,
                entryFee: 0,
                prizePool: '',
                timeControl: 10,
                increment: 2,
                status: 'upcoming',
                startDate: new Date().toISOString().substring(0, 16),
                endDate: new Date(Date.now() + 86400000).toISOString().substring(0, 16),
            });
        }
        setFormOpen(true);
    };

    const handleTypeChange = (typeName: string) => {
        const selectedType = tournamentTypes.find(t => t.name === typeName);
        if (selectedType) {
            setCurrentTournament({
                ...currentTournament,
                type: selectedType.name,
                maxPlayers: selectedType.maxPlayers,
                rounds: selectedType.rounds,
                entryFee: selectedType.entryFee,
                prizePool: selectedType.prizePool,
                timeControl: selectedType.timeControl,
                increment: selectedType.increment
            });
        } else {
            setCurrentTournament({ ...currentTournament, type: typeName });
        }
    };

    const handleSave = async () => {
        try {
            const dataToSave = {
                ...currentTournament,
                startDate: Timestamp.fromDate(new Date(currentTournament.startDate)),
                endDate: Timestamp.fromDate(new Date(currentTournament.endDate)),
            };

            if (isNew) {
                await createTournament(dataToSave);
            } else {
                const { id, ...updateData } = dataToSave;
                await updateTournament(id, updateData);
            }
            setFormOpen(false);
        } catch (err) {
            setError('Failed to save tournament.');
        }
    };

    const handleDelete = async (id: string) => {
        if (window.confirm('Are you sure?')) {
            await deleteTournament(id);
        }
    };

    const { upcoming, ongoing, past } = useMemo(() => {
        return {
            upcoming: tournaments.filter(t => t.status === 'upcoming'),
            ongoing: tournaments.filter(t => t.status === 'ongoing'),
            past: tournaments.filter(t => t.status === 'completed' || t.status === 'cancelled')
        };
    }, [tournaments]);

    return (
        <Box sx={{ p: 1 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
                <Typography variant="h4" sx={{ fontWeight: 'bold' }}>Tournament Management</Typography>
                <Button variant="contained" startIcon={<Add />} onClick={() => handleOpenForm()}>Create Tournament</Button>
            </Box>

            {loading ? <CircularProgress /> : (
                <>
                    <Accordion defaultExpanded sx={{ mb: 2, borderRadius: '12px !important' }}>
                        <AccordionSummary expandIcon={<ExpandMore />}><Typography variant="h6">Upcoming ({upcoming.length})</Typography></AccordionSummary>
                        <AccordionDetails><TournamentTable tournaments={upcoming} onEdit={handleOpenForm} onDelete={handleDelete} onGenerateBracket={generateBracket} onManageBracket={(t) => {setSelectedTournamentForBracket(t); setBracketOpen(true);}} onResetBracket={resetBracket} /></AccordionDetails>
                    </Accordion>
                    <Accordion defaultExpanded sx={{ mb: 2, borderRadius: '12px !important' }}>
                        <AccordionSummary expandIcon={<ExpandMore />}><Typography variant="h6">Ongoing ({ongoing.length})</Typography></AccordionSummary>
                        <AccordionDetails><TournamentTable tournaments={ongoing} onEdit={handleOpenForm} onDelete={handleDelete} onGenerateBracket={generateBracket} onManageBracket={(t) => {setSelectedTournamentForBracket(t); setBracketOpen(true);}} onResetBracket={resetBracket} /></AccordionDetails>
                    </Accordion>
                </>
            )}

            <Dialog open={formOpen} onClose={() => setFormOpen(false)} maxWidth="md" fullWidth>
                <DialogTitle>{isNew ? 'Create New Tournament' : 'Edit Tournament'}</DialogTitle>
                <DialogContent>
                    {currentTournament && (
                        <Grid container spacing={2} sx={{ mt: 1 }}>
                            <Grid item xs={12} sm={6}>
                                <TextField fullWidth label="Tournament Name" value={currentTournament.name} onChange={(e) => setCurrentTournament({...currentTournament, name: e.target.value})} />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <FormControl fullWidth>
                                    <InputLabel>Tournament Type (Template)</InputLabel>
                                    <Select value={currentTournament.type} onChange={(e) => handleTypeChange(e.target.value as string)}>
                                        {tournamentTypes.map(type => (
                                            <MenuItem key={type.id} value={type.name}>{type.name} (Auto-Fill)</MenuItem>
                                        ))}
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={6} sm={3}><TextField fullWidth type="number" label="Max Players" value={currentTournament.maxPlayers} onChange={(e) => setCurrentTournament({...currentTournament, maxPlayers: parseInt(e.target.value)})} /></Grid>
                            <Grid item xs={6} sm={3}><TextField fullWidth type="number" label="Rounds" value={currentTournament.rounds} onChange={(e) => setCurrentTournament({...currentTournament, rounds: parseInt(e.target.value)})} /></Grid>
                            <Grid item xs={6} sm={3}><TextField fullWidth type="number" label="Time (Mins)" value={currentTournament.timeControl} onChange={(e) => setCurrentTournament({...currentTournament, timeControl: parseInt(e.target.value)})} /></Grid>
                            <Grid item xs={6} sm={3}><TextField fullWidth type="number" label="Inc (Secs)" value={currentTournament.increment} onChange={(e) => setCurrentTournament({...currentTournament, increment: parseInt(e.target.value)})} /></Grid>
                            <Grid item xs={12} sm={6}><TextField fullWidth label="Prize Pool" value={currentTournament.prizePool} onChange={(e) => setCurrentTournament({...currentTournament, prizePool: e.target.value})} /></Grid>
                            <Grid item xs={12} sm={6}><TextField fullWidth type="number" label="Entry Fee" value={currentTournament.entryFee} onChange={(e) => setCurrentTournament({...currentTournament, entryFee: parseInt(e.target.value)})} /></Grid>
                            <Grid item xs={12} sm={6}><TextField fullWidth type="datetime-local" label="Start Date" value={currentTournament.startDate} onChange={(e) => setCurrentTournament({...currentTournament, startDate: e.target.value})} InputLabelProps={{ shrink: true }} /></Grid>
                            <Grid item xs={12} sm={6}><TextField fullWidth type="datetime-local" label="End Date" value={currentTournament.endDate} onChange={(e) => setCurrentTournament({...currentTournament, endDate: e.target.value})} InputLabelProps={{ shrink: true }} /></Grid>
                        </Grid>
                    )}
                </DialogContent>
                <DialogActions sx={{ p: 3 }}>
                    <Button onClick={() => setFormOpen(false)}>Cancel</Button>
                    <Button onClick={handleSave} variant="contained" sx={{ px: 4 }}>{isNew ? 'Create' : 'Save Changes'}</Button>
                </DialogActions>
            </Dialog>

            <Dialog open={bracketOpen} onClose={() => setBracketOpen(false)} maxWidth="lg" fullWidth>
                <DialogTitle>Tournament Bracket: {selectedTournamentForBracket?.name}</DialogTitle>
                <DialogContent>
                    {selectedTournamentForBracket && <BracketView tournament={selectedTournamentForBracket} onUpdate={() => {}} />}
                </DialogContent>
                <DialogActions><Button onClick={() => setBracketOpen(false)}>Close</Button></DialogActions>
            </Dialog>
        </Box>
    );
};

export default TournamentManagement;
