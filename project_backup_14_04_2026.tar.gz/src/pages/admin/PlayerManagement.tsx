
import React, { useState, useEffect } from 'react';
import { 
    Box, 
    Button, 
    CircularProgress, 
    Paper, 
    Table, 
    TableBody, 
    TableCell, 
    TableContainer, 
    TableHead, 
    TableRow, 
    Typography, 
    Alert,
    Switch,
    FormControlLabel,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Select,
    MenuItem,
    InputLabel,
    FormControl
} from '@mui/material';
import { Delete, Add } from '@mui/icons-material';
import { getUsers, updateUser, deleteUser, UserData } from '../../utils/firebase/users';
import { getTournamentsRT, addPlayerToTournament, Tournament } from '../../utils/firebase/tournaments';

const PlayerManagement: React.FC = () => {
    const [players, setPlayers] = useState<UserData[]>([]);
    const [tournaments, setTournaments] = useState<Tournament[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [open, setOpen] = useState(false);
    const [selectedPlayer, setSelectedPlayer] = useState<UserData | null>(null);
    const [selectedTournament, setSelectedTournament] = useState('');

    const fetchPlayers = async () => {
        try {
            setLoading(true);
            const data = await getUsers();
            setPlayers(data);
            setError(null);
        } catch (err) {
            setError('Failed to fetch players.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchPlayers();
        const unsubscribe = getTournamentsRT(
            (data) => setTournaments(data),
            (err) => console.error("Failed to fetch tournaments", err)
        );
        return () => unsubscribe();
    }, []);

    const handleRoleChange = async (player: UserData, isAdmin: boolean) => {
        const updatedPlayer = { ...player, isAdmin };
        const { uid, ...data } = updatedPlayer;
        try {
            await updateUser(uid, data);
            setPlayers(players.map(p => p.uid === uid ? updatedPlayer : p));
        } catch (err) {
            setError(`Failed to update role for ${player.displayName}.`);
            console.error(err);
        }
    };
    
    const handleDelete = async (uid: string) => {
        if (window.confirm('Are you sure you want to permanently delete this user?')) {
            try {
                await deleteUser(uid);
                fetchPlayers(); // Refetch players after deletion
            } catch (err) {
                setError('Failed to delete user.');
                console.error(err);
            }
        }
    };

    const handleOpenModal = (player: UserData) => {
        setSelectedPlayer(player);
        setOpen(true);
    };

    const handleCloseModal = () => {
        setOpen(false);
        setSelectedPlayer(null);
        setSelectedTournament('');
    };

    const handleAddPlayerToTournament = async () => {
        if (!selectedPlayer || !selectedTournament) return;

        try {
            await addPlayerToTournament(selectedTournament, { uid: selectedPlayer.uid, displayName: selectedPlayer.displayName, photoURL: selectedPlayer.photoURL });
            handleCloseModal();
        } catch (error) {
            setError('Failed to add player to tournament.');
            console.error(error);
        }
    };

    return (
        <Box>
            <Typography variant="h4" component="h1" sx={{ mb: 4, fontWeight: 'bold' }}>
                Player Management
            </Typography>
            
            {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

            {loading ? (
                <CircularProgress />
            ) : (
                <TableContainer component={Paper}>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell>Name</TableCell>
                                <TableCell>Email</TableCell>
                                <TableCell>Admin</TableCell>
                                <TableCell>Actions</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {players.map((player) => (
                                <TableRow key={player.uid}>
                                    <TableCell>{player.displayName || 'N/A'}</TableCell>
                                    <TableCell>{player.email}</TableCell>
                                    <TableCell>
                                        <FormControlLabel
                                            control={
                                                <Switch
                                                    checked={player.isAdmin || false}
                                                    onChange={(e) => handleRoleChange(player, e.target.checked)}
                                                />
                                            }
                                            label={player.isAdmin ? 'Yes' : 'No'}
                                        />
                                    </TableCell>
                                    <TableCell>
                                        <Button size="small" color="error" onClick={() => handleDelete(player.uid)}><Delete /></Button>
                                        <Button size="small" startIcon={<Add />} onClick={() => handleOpenModal(player)}>Add to Tournament</Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            )}
             <Dialog open={open} onClose={handleCloseModal}>
                <DialogTitle>Add {selectedPlayer?.displayName} to Tournament</DialogTitle>
                <DialogContent>
                    <FormControl fullWidth sx={{mt: 2}}>
                        <InputLabel>Tournament</InputLabel>
                        <Select
                            value={selectedTournament}
                            label="Tournament"
                            onChange={(e) => setSelectedTournament(e.target.value as string)}
                        >
                            {tournaments.map((tournament) => (
                                <MenuItem key={tournament.id} value={tournament.id}>{tournament.name}</MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseModal}>Cancel</Button>
                    <Button onClick={handleAddPlayerToTournament} variant="contained">Add</Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
};

export default PlayerManagement;
