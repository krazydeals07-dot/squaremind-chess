import React, { useState, useEffect } from 'react';
import { 
    Box, Button, TextField, Typography, Paper, Table, TableBody, 
    TableCell, TableContainer, TableHead, TableRow, IconButton, 
    Alert, CircularProgress, Divider, Grid, Card, CardContent 
} from '@mui/material';
import { Delete, Edit, Add, Save, Settings as SettingsIcon } from '@mui/icons-material';
import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../../firebase';

interface TournamentType {
    id: string;
    name: string;
    maxPlayers: number;
    rounds: number;
    entryFee: number;
    prizePool: string;
    timeControl: number; // in minutes
    increment: number; // in seconds
}

const TournamentTypeManagement: React.FC = () => {
    const [types, setTypes] = useState<TournamentType[]>([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<string | null>(null);
    const [editId, setEditId] = useState<string | null>(null);

    const [formData, setFormData] = useState<Omit<TournamentType, 'id'>>({
        name: '',
        maxPlayers: 32,
        rounds: 5,
        entryFee: 0,
        prizePool: '',
        timeControl: 10,
        increment: 2
    });

    const fetchTypes = async () => {
        try {
            setLoading(true);
            const colRef = collection(db, 'tournamentTypes');
            const snapshot = await getDocs(colRef);
            const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as TournamentType));
            setTypes(data || []);
        } catch (err) {
            console.error(err);
            setError('Failed to fetch tournament types.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchTypes();
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.name.trim()) return;

        setSaving(true);
        setError(null);
        setSuccess(null);

        try {
            if (editId) {
                const docRef = doc(db, 'tournamentTypes', editId);
                await updateDoc(docRef, { ...formData });
                setSuccess('Tournament type updated successfully!');
            } else {
                const colRef = collection(db, 'tournamentTypes');
                await addDoc(colRef, { ...formData });
                setSuccess('New tournament type template added!');
            }
            setFormData({
                name: '', maxPlayers: 32, rounds: 5, entryFee: 0, prizePool: '', timeControl: 10, increment: 2
            });
            setEditId(null);
            fetchTypes();
        } catch (err) {
            setError('Failed to save tournament type.');
        } finally {
            setSaving(false);
        }
    };

    const handleEdit = (type: TournamentType) => {
        const { id, ...data } = type;
        setFormData(data);
        setEditId(id);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleDelete = async (id: string) => {
        if (window.confirm('Delete this tournament template? This will not affect existing tournaments.')) {
            try {
                await deleteDoc(doc(db, 'tournamentTypes', id));
                setSuccess('Template deleted.');
                fetchTypes();
            } catch (err) {
                setError('Failed to delete template.');
            }
        }
    };

    return (
        <Box sx={{ maxWidth: 1100 }}>
            <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold' }}>Tournament Type & Rules</Typography>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 4 }}>
                Define templates for different tournament formats. These settings will pre-fill when creating new tournaments.
            </Typography>

            {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
            {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

            <Paper sx={{ p: 4, mb: 4, borderRadius: '12px', border: '1px solid #e0e0e0' }}>
                <Typography variant="h6" gutterBottom display="flex" alignItems="center">
                    <SettingsIcon sx={{ mr: 1, color: 'primary.main' }} /> {editId ? 'Edit Template' : 'Create New Template'}
                </Typography>
                <Divider sx={{ mb: 3 }} />
                
                <form onSubmit={handleSubmit}>
                    <Grid container spacing={3}>
                        <Grid item xs={12} sm={6} md={4}>
                            <TextField fullWidth label="Template Name (e.g. Blitz Pro)" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} required />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4}>
                            <TextField fullWidth type="number" label="Max Players" value={formData.maxPlayers} onChange={(e) => setFormData({...formData, maxPlayers: parseInt(e.target.value)})} required />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4}>
                            <TextField fullWidth type="number" label="Total Rounds/Levels" value={formData.rounds} onChange={(e) => setFormData({...formData, rounds: parseInt(e.target.value)})} required />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4}>
                            <TextField fullWidth type="number" label="Entry Fee (₹)" value={formData.entryFee} onChange={(e) => setFormData({...formData, entryFee: parseInt(e.target.value)})} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4}>
                            <TextField fullWidth label="Prize Pool Details" placeholder="e.g. Winner: ₹1000, 2nd: ₹500" value={formData.prizePool} onChange={(e) => setFormData({...formData, prizePool: e.target.value})} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={2}>
                            <TextField fullWidth type="number" label="Time (Mins)" value={formData.timeControl} onChange={(e) => setFormData({...formData, timeControl: parseInt(e.target.value)})} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={2}>
                            <TextField fullWidth type="number" label="Inc (Secs)" value={formData.increment} onChange={(e) => setFormData({...formData, increment: parseInt(e.target.value)})} />
                        </Grid>
                        <Grid item xs={12} sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                            {editId && <Button variant="outlined" onClick={() => { setEditId(null); setFormData({name: '', maxPlayers: 32, rounds: 5, entryFee: 0, prizePool: '', timeControl: 10, increment: 2}); }}>Cancel</Button>}
                            <Button type="submit" variant="contained" size="large" sx={{ px: 4 }} disabled={saving}>
                                {saving ? <CircularProgress size={24} color="inherit" /> : (editId ? 'Update Template' : 'Save Template')}
                            </Button>
                        </Grid>
                    </Grid>
                </form>
            </Paper>

            <TableContainer component={Paper} sx={{ borderRadius: '12px', border: '1px solid #e0e0e0' }}>
                <Table>
                    <TableHead sx={{ bgcolor: '#f8f9fa' }}>
                        <TableRow>
                            <TableCell sx={{ fontWeight: 'bold' }}>Format Name</TableCell>
                            <TableCell sx={{ fontWeight: 'bold' }}>Players/Rounds</TableCell>
                            <TableCell sx={{ fontWeight: 'bold' }}>Entry/Prize</TableCell>
                            <TableCell sx={{ fontWeight: 'bold' }}>Time Control</TableCell>
                            <TableCell align="right" sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {loading && types.length === 0 ? (
                            <TableRow><TableCell colSpan={5} align="center"><CircularProgress /></TableCell></TableRow>
                        ) : types.length === 0 ? (
                            <TableRow><TableCell colSpan={5} align="center">No templates defined yet.</TableCell></TableRow>
                        ) : (
                            types.map((type) => (
                                <TableRow key={type.id} hover>
                                    <TableCell sx={{ fontWeight: 600 }}>{type.name}</TableCell>
                                    <TableCell>{`${type.maxPlayers} Players / ${type.rounds} Rds`}</TableCell>
                                    <TableCell>{`₹${type.entryFee} / ${type.prizePool || 'None'}`}</TableCell>
                                    <TableCell>{`${type.timeControl} + ${type.increment}`}</TableCell>
                                    <TableCell align="right">
                                        <IconButton onClick={() => handleEdit(type)} color="primary"><Edit /></IconButton>
                                        <IconButton onClick={() => handleDelete(type.id)} color="error"><Delete /></IconButton>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </TableContainer>
        </Box>
    );
};

export default TournamentTypeManagement;
