import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { doc, onSnapshot, collection, query, orderBy, getDocs, Timestamp, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { 
    Container, Typography, Paper, Grid, TextField, Button, 
    Box, Avatar, CircularProgress, Tabs, Tab, LinearProgress, Divider,
    List, ListItem, ListItemText, ListItemAvatar, ListItemIcon
} from '@mui/material';
import { Edit, EmojiEvents, People, SportsEsports } from '@mui/icons-material';
import { achievementsList } from '../data/achievements';
import { UserProfile as UserProfileType, GameHistory as GameHistoryType, UnlockedAchievement, Stats } from '../types';
import StatsCategory from '../components/profile/StatsCategory';

const Profile = () => {
  const { currentUser, loading: authLoading } = useAuth();
  const [userProfile, setUserProfile] = useState<UserProfileType | null>(null);
  const [profileLoading, setProfileLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [tabValue, setTabValue] = useState(0);
  const [gameHistory, setGameHistory] = useState<GameHistoryType[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [editableProfile, setEditableProfile] = useState<UserProfileType | null>(null);

  useEffect(() => {
    if (currentUser) {
        setProfileLoading(true);
        const userRef = doc(db, 'users', currentUser.uid);
        const unsubscribe = onSnapshot(userRef, (docSnap) => {
            if (docSnap.exists()) {
                const profileData = docSnap.data() as UserProfileType;
                setUserProfile(profileData);
                setEditableProfile(profileData);
            }
            setProfileLoading(false);
        });
        return () => unsubscribe();
    } else {
        setProfileLoading(false);
        setUserProfile(null);
    }
  }, [currentUser]);

  const fetchGameHistory = useCallback(async () => {
      if (currentUser && tabValue === 2) {
          setHistoryLoading(true);
          try {
            const historyCollectionRef = collection(db, 'users', currentUser.uid, 'gameHistory');
            const q = query(historyCollectionRef, orderBy('playedAt', 'desc'));
            const querySnapshot = await getDocs(q);
            const history = querySnapshot.docs.map(doc => doc.data() as GameHistoryType);
            setGameHistory(history);
          } catch (error) {
            console.error("Error fetching game history:", error);
          } finally {
            setHistoryLoading(false);
          }
      }
  }, [currentUser, tabValue]);

  useEffect(() => {
      if (tabValue === 2) fetchGameHistory();
  }, [tabValue, fetchGameHistory]);

  const handleSave = async () => {
    if (editableProfile && currentUser) {
      const docRef = doc(db, 'users', currentUser.uid);
      await setDoc(docRef, editableProfile, { merge: true });
      setIsEditing(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (editableProfile) {
      setEditableProfile({ ...editableProfile, [e.target.name]: e.target.value });
    }
  };

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };
  
  if (authLoading || profileLoading) {
    return <Container><Box sx={{ display: 'flex', justifyContent: 'center', mt: 5 }}><CircularProgress color="warning" /></Box></Container>;
  }

  if (!currentUser || !userProfile) {
    return <Container><Typography color="white" sx={{textAlign: 'center', mt: 5}}>Please log in to view your profile.</Typography></Container>;
  }
  
  const { photoURL } = currentUser || {};
  const { displayName = 'User', level = 1, aiStats, friendsStats, tournamentsStats, unlockedAchievements = [] } = userProfile || {};
  const levelProgress = level ? (level - Math.floor(level)) * 100 : 0;

  const safeUnlockedAchievements: UnlockedAchievement[] = Array.isArray(unlockedAchievements) ? unlockedAchievements : [];

  return (
    <Box sx={{ color: 'white', fontFamily: '"Orbitron", sans-serif', py: { xs: 1, md: 4 }, mb: { xs: 4, md: 6 } }}>
        <Container maxWidth="xl" sx={{ px: { xs: 1, sm: 2, md: 3 } }}>
            <Paper 
                elevation={12} 
                sx={{ 
                    background: 'rgba(20, 20, 30, 0.85)',
                    backdropFilter: 'blur(20px)',
                    p: { xs: 2, md: 4 }, 
                    borderRadius: '24px',
                    border: '1px solid rgba(255, 255, 255, 0.1)'
                }}
            >
                <Grid container spacing={{ xs: 3, md: 5 }}>
                    <Grid item xs={12} md={4}>
                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
                            <Avatar 
                                src={photoURL || userProfile?.photoURL || ''} 
                                sx={{ 
                                    width: { xs: 120, md: 180 }, 
                                    height: { xs: 120, md: 180 }, 
                                    mb: 2, 
                                    border: '5px solid #FFA500',
                                    boxShadow: '0 0 20px #FFA500'
                                }}
                            >
                                <Typography variant="h1" sx={{ fontFamily: '"Orbitron", sans-serif', fontSize: { xs: '4rem', md: '6rem' } }}>
                                    {displayName?.charAt(0)?.toUpperCase() || 'U'}
                                </Typography>
                            </Avatar>
                            <Typography variant="h4" component="h1" sx={{ fontFamily: '"Orbitron", sans-serif', color: '#FFA500', fontWeight: 'bold' }}>
                                {displayName}
                            </Typography>
                            <Typography sx={{ color: '#08d4b4', fontFamily: '"Orbitron", sans-serif', mb: 2 }}>
                                {`Level ${Math.floor(level)}`}
                            </Typography>
                            <Box sx={{ width: '90%', mb: 3 }}>
                                <LinearProgress 
                                    variant="determinate" 
                                    value={levelProgress}
                                    sx={{ 
                                        height: 10, 
                                        borderRadius: 5, 
                                        bgcolor: 'rgba(255,255,255,0.1)',
                                        '& .MuiLinearProgress-bar': { 
                                            background: 'linear-gradient(90deg, #E03D00, #FFA500)',
                                            boxShadow: '0 0 10px #FFA500'
                                        } 
                                    }} 
                                />
                            </Box>
                            <Button 
                                variant="contained" 
                                startIcon={<Edit />} 
                                sx={{ 
                                    fontFamily: '"Orbitron", sans-serif',
                                    bgcolor: isEditing ? '#E03D00' : '#08d4b4', 
                                    '&:hover': { bgcolor: isEditing ? '#FFA500' : '#07bfa0' },
                                    borderRadius: '12px',
                                    px: 3,
                                    py: 1
                                }}
                                onClick={() => setIsEditing(!isEditing)}
                            >
                                {isEditing ? 'Cancel' : 'Edit Profile'}
                            </Button>
                        </Box>
                    </Grid>

                    <Grid item xs={12} md={8}>
                        {isEditing ? (
                            <Box component="form" noValidate autoComplete="off" sx={{ p: 2 }}>
                                <Grid container spacing={3}>
                                    <Grid item xs={12}>
                                        <TextField fullWidth variant="filled" label="Display Name" name="displayName" defaultValue={editableProfile?.displayName || ''} onChange={handleChange} InputLabelProps={{ style: { color: 'white' } }} InputProps={{ style: { color: 'white', backgroundColor: 'rgba(0,0,0,0.3)' } }} />
                                    </Grid>
                                     <Grid item xs={12} sm={6}>
                                        <TextField fullWidth variant="filled" label="Mobile Number" name="mobileNumber" defaultValue={editableProfile?.mobileNumber || ''} onChange={handleChange} InputLabelProps={{ style: { color: 'white' } }} InputProps={{ style: { color: 'white', backgroundColor: 'rgba(0,0,0,0.3)' } }} />
                                    </Grid>
                                     <Grid item xs={12} sm={6}>
                                        <TextField fullWidth variant="filled" label="Date of Birth" name="dob" type="date" defaultValue={editableProfile?.dob ? new Date(editableProfile.dob).toISOString().split('T')[0] : ''} onChange={handleChange} InputLabelProps={{ style: { color: 'white' }, shrink: true }} InputProps={{ style: { color: 'white', backgroundColor: 'rgba(0,0,0,0.3)' } }} />
                                    </Grid>
                                     <Grid item xs={12}>
                                        <TextField fullWidth variant="filled" label="Address" name="address" defaultValue={editableProfile?.address || ''} onChange={handleChange} InputLabelProps={{ style: { color: 'white' } }} InputProps={{ style: { color: 'white', backgroundColor: 'rgba(0,0,0,0.3)' } }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6}>
                                        <TextField fullWidth variant="filled" label="Country" name="country" defaultValue={editableProfile?.country || ''} onChange={handleChange} InputLabelProps={{ style: { color: 'white' } }} InputProps={{ style: { color: 'white', backgroundColor: 'rgba(0,0,0,0.3)' } }} />
                                    </Grid>
                                </Grid>
                                <Button onClick={handleSave} variant="contained" sx={{ mt: 3, bgcolor: '#FFA500', fontFamily: '"Orbitron", sans-serif', '&:hover': { bgcolor: '#E03D00' } }}>
                                    Save Changes
                                </Button>
                            </Box>
                        ) : (
                            <Box sx={{ width: '100%' }}>
                                <Tabs 
                                    value={tabValue} 
                                    onChange={handleTabChange} 
                                    variant="scrollable"
                                    scrollButtons="auto"
                                    allowScrollButtonsMobile
                                    sx={{ 
                                        mb: { xs: 2, md: 3 }, 
                                        '& .MuiTabs-indicator': { background: 'linear-gradient(90deg, #E03D00, #FFA500)', height: 4 }, 
                                        '& .MuiTab-root': { color: 'rgba(255,255,255,0.7)', fontFamily: '"Orbitron", sans-serif', minWidth: 'auto', px: 2 }, 
                                        '& .Mui-selected': { color: '#FFA500' } 
                                    }}
                                >
                                    <Tab label="Statistics" />
                                    <Tab label="Achievements" />
                                    <Tab label="Game History" />
                                </Tabs>

                                {tabValue === 0 && (
                                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: { xs: 3, md: 4 }, p: { xs: 1, md: 2 } }}>
                                      <StatsCategory title="Play with AI" stats={aiStats} icon={<SportsEsports />} />
                                      <Divider sx={{ bgcolor: 'rgba(255,255,255,0.2)' }} />
                                       <StatsCategory title="Play with Friends" stats={friendsStats} icon={<People />} />
                                      <Divider sx={{ bgcolor: 'rgba(255,255,255,0.2)' }} />
                                       <StatsCategory title="Tournaments" stats={tournamentsStats} icon={<EmojiEvents />} />
                                    </Box>
                                )}
                                {tabValue === 1 && (
                                     <Box sx={{ p: { xs: 1, md: 2 } }}>
                                        <List dense sx={{ bgcolor: 'rgba(0,0,0,0.2)', borderRadius: '8px' }}>
                                            {achievementsList.map((ach) => {
                                                const unlocked = safeUnlockedAchievements.find(ua => ua.id === ach.id);
                                                const iconElement = typeof ach.icon === 'string' ? <Typography sx={{fontSize: '2.5rem'}}>{ach.icon}</Typography> : ach.icon;
                                                
                                                const unlockedDate = unlocked && unlocked.unlockedAt && unlocked.unlockedAt.seconds 
                                                    ? new Date(unlocked.unlockedAt.seconds * 1000).toLocaleDateString()
                                                    : null;

                                                return (
                                                    <ListItem key={ach.id} divider sx={{ opacity: unlocked ? 1 : 0.4 }}>
                                                         <ListItemIcon sx={{ fontSize: '2.5rem', color: unlocked ? '#FFD700' : 'grey' }}>
                                                            {iconElement}
                                                        </ListItemIcon>
                                                        <ListItemText 
                                                            primary={ach.name}
                                                            secondary={unlockedDate ? `Unlocked on ${unlockedDate}` : ach.description}
                                                            primaryTypographyProps={{ color: unlocked ? 'white' : 'grey' }}
                                                            secondaryTypographyProps={{ color: 'grey' }}
                                                        />
                                                    </ListItem>
                                                );
                                            })}
                                        </List>
                                    </Box>
                                )}
                                {tabValue === 2 && (
                                    <Box sx={{ p: { xs: 1, md: 2 } }}>
                                        {historyLoading ? (
                                            <CircularProgress color="warning" />
                                        ) : gameHistory.length === 0 ? (
                                            <Typography sx={{ textAlign: 'center', p: 5 }}>No game history yet.</Typography>
                                        ) : (
                                            <List dense sx={{ bgcolor: 'rgba(0,0,0,0.2)', borderRadius: '8px' }}>
                                                {gameHistory.map((game, index) => {
                                                    const playedDate = game.playedAt && game.playedAt.seconds
                                                        ? new Date(game.playedAt.seconds * 1000).toLocaleDateString()
                                                        : 'Date not available';

                                                    return (
                                                        <ListItem key={game.gameId || index} divider>
                                                            <ListItemAvatar>
                                                                 <Avatar src={game.opponent.photoURL || undefined} />
                                                            </ListItemAvatar>
                                                            <ListItemText 
                                                                 primary={`vs ${game.opponent.name}`}
                                                                 secondary={`${game.result ? game.result.toUpperCase() : 'N/A'} - ${playedDate}`}
                                                                primaryTypographyProps={{ 
                                                                    color: game.result && game.result.toLowerCase() === 'win' ? '#4caf50' : game.result && game.result.toLowerCase() === 'loss' ? '#f44336' : 'white' 
                                                                }}
                                                                secondaryTypographyProps={{ color: 'grey' }}
                                                            />
                                                        </ListItem>
                                                    );
                                                })}
                                            </List>
                                        )}
                                    </Box>
                                )}
                            </Box>
                        )}
                    </Grid>
                </Grid>
            </Paper>
        </Container>
    </Box>
  );
};

export default Profile;