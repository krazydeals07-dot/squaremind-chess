
import { useState, useEffect } from 'react';
import { collection, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { Container, Typography, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Avatar, Box, CircularProgress } from '@mui/material';
import { UserProfile } from '../types';
import ChessIcon from '../components/ChessIcon';

const LeaderboardPage = () => {
    const [leaderboard, setLeaderboard] = useState<UserProfile[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchLeaderboard = async () => {
            try {
                const usersRef = collection(db, 'users');
                const q = query(usersRef, orderBy("stats.rating", "desc"), limit(100));
                const querySnapshot = await getDocs(q);
                const users: UserProfile[] = [];
                querySnapshot.forEach((doc) => {
                    users.push(doc.data() as UserProfile);
                });
                setLeaderboard(users);
                setLoading(false);
            } catch (error) {
                console.error("Error fetching leaderboard: ", error);
                setLoading(false);
            }
        };

        fetchLeaderboard();
    }, []);

    return (
        <Container maxWidth="md" sx={{ mt: 4 }}>
            <Paper sx={{ p: 2, background: 'rgba(0,0,0,0.7)' }}>
                <ChessIcon />
                <Typography variant="h4" gutterBottom align="center" sx={{ fontFamily: '"Orbitron", sans-serif', mb: 3, color: '#FFA500', textTransform: 'uppercase', fontWeight: 'bold' }}>
                    Global Leaderboard
                </Typography>
                {loading ? (
                    <Box sx={{ display: 'flex', justifyContent: 'center', my: 3}}>
                         <CircularProgress />
                    </Box>
                ) : (
                    <TableContainer>
                        <Table>
                            <TableHead>
                                <TableRow>
                                    <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Rank</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Player</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 'bold' }} align="right">Rating</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 'bold' }} align="right">Games</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {leaderboard.map((user, index) => (
                                    <TableRow key={user.uid} sx={{ '&:nth-of-type(odd)': { backgroundColor: 'rgba(255,255,255,0.05)' } }}>
                                        <TableCell sx={{ color: 'white' }}>{index + 1}</TableCell>
                                        <TableCell sx={{ color: 'white' }}>
                                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                                <Avatar src={user.photoURL} sx={{ mr: 2, width: 32, height: 32 }} />
                                                {user.displayName}
                                            </Box>
                                        </TableCell>
                                        <TableCell sx={{ color: 'white' }} align="right">{user.stats.rating}</TableCell>
                                        <TableCell sx={{ color: 'white' }} align="right">{user.stats.gamesPlayed}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                )}
            </Paper>
        </Container>
    );
};

export default LeaderboardPage;
