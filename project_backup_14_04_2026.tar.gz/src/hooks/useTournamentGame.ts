import { useState, useEffect, useCallback, useMemo } from 'react';
import { doc, updateDoc, runTransaction, serverTimestamp, Firestore, DocumentReference } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { GameData } from '../types';
import { useGameData } from './useGameData';
import { useChessLogic } from './useChessLogic';
import { useGameTimer } from './useGameTimer';
import { Chess, Square } from 'chess.js';

const typedDb = db as Firestore;

export const useTournamentGame = (gameId: string) => {
    const { currentUser } = useAuth();
    const navigate = useNavigate();
    const userId = currentUser?.uid;

    const { gameData, loading: dataLoading, error } = useGameData(gameId);
    const { game, capturedBy, lastMoveSquares, optionSquares, isGameOver, onSquareClick, setFromSquare, setOptionSquares } = useChessLogic(gameData);

    const [gameResult, setGameResult] = useState<string | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [drawOffer, setDrawOffer] = useState<any>(null);

    const handleTimeout = useCallback(async (timedOutColor: 'w' | 'b') => {
        if (!gameData || gameData.status !== 'active') return;
        const gameDocRef = doc(typedDb, 'games', gameId);
        try {
            await runTransaction(typedDb, async (transaction) => {
                const gameDoc = await transaction.get(gameDocRef as DocumentReference<GameData>);
                if (gameDoc.exists() && gameDoc.data().status === 'active') {
                    const winnerColor = timedOutColor === 'w' ? 'b' : 'w';
                    const winnerId = gameDoc.data().players[winnerColor === 'w' ? 'white' : 'black'];
                    transaction.update(gameDocRef, {
                        status: 'ended',
                        result: { winnerId, reason: 'timeout' }
                    });
                }
            });
        } catch (err) {
            console.error("Timeout transaction failed: ", err);
        }
    }, [gameId, gameData]);

    const timers = useGameTimer(gameData, handleTimeout);

    const isMyTurn = useMemo(() => {
        if (!gameData || !userId || isGameOver || gameData.status !== 'active') return false;
        const playerColor = gameData.players.white === userId ? 'w' : 'b';
        return game.turn() === playerColor;
    }, [game, gameData, userId, isGameOver]);

    const makeMove = useCallback(async (move: { from: Square, to: Square, promotion?: string }) => {
        if (!isMyTurn || !gameData) return;

        const gameCopy = new Chess(game.fen());
        const moveResult = gameCopy.move(move);

        if (moveResult) {
            const turnOfPlayerWhoMoved = game.turn(); // turn before the move
            const lastMoveTime = gameData.lastMoveTimestamp?.toDate().getTime() || gameData.createdAt.toDate().getTime();
            const elapsed = (Date.now() - lastMoveTime) / 1000;
            const increment = gameData.timeIncrement || 0;

            const newTimers = { ...gameData.timers };
            newTimers[turnOfPlayerWhoMoved] = (newTimers[turnOfPlayerWhoMoved] || 0) - elapsed + increment;

            const updatePayload: any = {
                fen: gameCopy.fen(),
                moves: [...(gameData.moves || []), { san: moveResult.san, from: moveResult.from, to: moveResult.to }],
                lastMoveTimestamp: serverTimestamp(),
                timers: newTimers,
            };

            // If it's the first move and the game is not already active, set status to 'active'.
            if ((!gameData.moves || gameData.moves.length === 0) && gameData.status !== 'active') {
                updatePayload.status = 'active';
            }
            
            await updateDoc(doc(typedDb, 'games', gameId), updatePayload);
        }
        setFromSquare(null);
        setOptionSquares({});
    }, [isMyTurn, game, gameData, gameId]);

    const processGameOver = useCallback(async (currentGame: Chess) => {
        if (!gameData || gameData.status !== 'active') return;
        try {
            await runTransaction(typedDb, async (transaction) => {
                const gameDocRef = doc(typedDb, 'games', gameId);
                const freshGameDoc = await transaction.get(gameDocRef as DocumentReference<GameData>);
                if (!freshGameDoc.exists() || freshGameDoc.data().status !== 'active') return;

                const currentGamedata = freshGameDoc.data();
                let result: { winnerId?: string; reason: string; } = { reason: 'unknown' };

                if (currentGame.isCheckmate()) {
                    const winnerId = currentGame.turn() === 'b' ? currentGamedata.players.white : currentGamedata.players.black;
                    result = { winnerId, reason: 'checkmate' };
                } else if (currentGame.isDraw()) {
                    result = { reason: 'draw' };
                } else if (currentGame.isStalemate()) {
                    result = { reason: 'stalemate' };
                } else if (currentGame.isThreefoldRepetition()) {
                    result = { reason: 'repetition' };
                } else if (currentGame.isInsufficientMaterial()) {
                    result = { reason: 'insufficient material' };
                }

                transaction.update(gameDocRef, { status: 'ended', result });
            });
        } catch (e) {
            console.error("Game Over Transaction failed: ", e);
        }
    }, [gameId, gameData]);

    useEffect(() => {
        if (isGameOver && gameData?.status === 'active') {
            processGameOver(game);
        }
    }, [isGameOver, gameData, game, processGameOver]);

    const showGameResult = useCallback((data: GameData) => {
        if (data.status === 'ended' && !isModalOpen) {
            const { result, playerNames } = data;
            let message = "Game Over";
            if (result && playerNames) {
                const winnerId = result.winnerId;
                if (winnerId) {
                    if (winnerId === userId) {
                        message = `Congratulations! You won by ${result.reason}.`;
                    } else {
                        const winnerName = winnerId === data.players.white ? playerNames.white : playerNames.black;
                        message = `${winnerName} won by ${result.reason}.`;
                    }
                } else {
                    message = `The game is a draw due to ${result.reason}.`;
                }
            }
            setGameResult(message);
            setIsModalOpen(true);
        }
    }, [isModalOpen, userId]);

    useEffect(() => {
        if (gameData) {
            setDrawOffer(gameData.drawOffer || null);
            if (gameData.status === 'ended') {
                showGameResult(gameData);
            }
        }
    }, [gameData, showGameResult]);

    const handleSquareClickWrapper = (square: Square) => {
        onSquareClick(square, isMyTurn, makeMove);
    }

    const resign = async () => {
        if (!gameData || gameData.status !== 'active') return;
        const winnerId = userId === gameData.players.white ? gameData.players.black : gameData.players.white;
        await updateDoc(doc(typedDb, 'games', gameId), {
            status: 'ended',
            result: { winnerId, reason: 'resignation' }
        });
    };

    const offerDraw = async () => {
        if (!gameData || gameData.status !== 'active' || drawOffer) return;
        const opponentId = userId === gameData.players.white ? gameData.players.black : gameData.players.white;
        await updateDoc(doc(typedDb, 'games', gameId), {
            drawOffer: { from: userId, to: opponentId }
        });
    };

    const acceptDraw = async () => {
        if (!gameData || !drawOffer || drawOffer.to !== userId) return;
        await updateDoc(doc(typedDb, 'games', gameId), {
            status: 'ended',
            result: { reason: 'draw by agreement' },
            drawOffer: null
        });
    };

    const declineDraw = async () => {
        if (!gameData || !drawOffer || drawOffer.to !== userId) return;
        await updateDoc(doc(typedDb, 'games', gameId), {
            drawOffer: null
        });
    };

    const closeModal = () => {
        setIsModalOpen(false);
        if (gameData?.tournamentId) {
            navigate(`/tournaments/${gameData.tournamentId}`);
        } else {
            navigate('/');
        }
    };
    
    const loading = dataLoading || !gameData || !game || !timers;

    return {
        game,
        gameData,
        timers,
        error,
        capturedBy,
        gameResult,
        isModalOpen,
        drawOffer,
        optionSquares,
        lastMoveSquares,
        onSquareClick: handleSquareClickWrapper,
        closeModal,
        resign,
        offerDraw,
        acceptDraw,
        declineDraw,
        isMyTurn,
        loading
    };
};