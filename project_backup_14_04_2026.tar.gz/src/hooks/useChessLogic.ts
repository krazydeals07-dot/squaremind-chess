import { useState, useEffect, useMemo } from 'react';
import { Chess, Square, Piece } from 'chess.js';
import { GameData } from '../types';

export const useChessLogic = (gameData: GameData | null) => {
    const [game, setGame] = useState(new Chess());
    const [capturedBy, setCapturedBy] = useState<{ w: Piece[], b: Piece[] }>({ w: [], b: [] });
    const [lastMoveSquares, setLastMoveSquares] = useState<{ [key: string]: React.CSSProperties }>({});
    const [fromSquare, setFromSquare] = useState<Square | null>(null);
    const [optionSquares, setOptionSquares] = useState<{ [key: string]: React.CSSProperties }>({});

    useEffect(() => {
        if (gameData) {
            const newGame = new Chess(gameData.fen);
            setGame(newGame);

            // Update captured pieces
            const history = newGame.history({ verbose: true });
            const captures = { w: [] as Piece[], b: [] as Piece[] };
            history.forEach(move => {
                if (move.captured) {
                    const piece: Piece = { type: move.captured, color: move.color === 'w' ? 'b' : 'w' };
                    (move.color === 'w' ? captures.w : captures.b).push(piece);
                }
            });
            setCapturedBy(captures);

            // Update last move highlighting
            if (history.length > 0) {
                const lastMove = history[history.length - 1];
                setLastMoveSquares({
                    [lastMove.from]: { background: 'rgba(255, 255, 0, 0.4)' },
                    [lastMove.to]: { background: 'rgba(255, 255, 0, 0.4)' },
                });
            } else {
                setLastMoveSquares({});
            }
        }
    }, [gameData?.fen]);

    const isGameOver = useMemo(() => game.isGameOver(), [game]);

    const handleSquareClick = (square: Square, isMyTurn: boolean, makeMove: (move: { from: Square, to: Square, promotion?: string }) => void) => {
        if (!isMyTurn) return;

        if (fromSquare) {
            if (fromSquare === square) {
                setFromSquare(null);
                setOptionSquares({});
                return;
            }
            makeMove({ from: fromSquare, to: square, promotion: 'q' }); // Assume promotion to queen for simplicity
            setFromSquare(null);
            setOptionSquares({});
        } else {
            const piece = game.get(square);
            if (piece && piece.color === game.turn()) {
                setFromSquare(square);
                const moves = game.moves({ square, verbose: true });
                const newOptionSquares = moves.reduce((acc, move) => {
                    acc[move.to] = {
                        background: game.get(move.to)
                            ? 'radial-gradient(circle, rgba(0,0,0,0.4) 85%, transparent 85%)'
                            : 'radial-gradient(circle, rgba(0,0,0,0.2) 25%, transparent 25%)',
                    };
                    return acc;
                }, {} as { [key: string]: React.CSSProperties });
                newOptionSquares[square] = { background: 'rgba(255, 255, 0, 0.4)' };
                setOptionSquares(newOptionSquares);
            }
        }
    };
    
    return { game, capturedBy, lastMoveSquares, optionSquares, isGameOver, onSquareClick: handleSquareClick, setFromSquare, setOptionSquares };
};