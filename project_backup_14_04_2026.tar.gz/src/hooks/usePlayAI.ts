import { useState, useEffect, useCallback, useRef } from 'react';
import { Chess, Square, Piece, Move } from 'chess.js';
import { useAuth } from '../contexts/AuthContext';
import { GameResult, GameResultType } from '../types';
import { doc, onSnapshot, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';

// --- Stockfish Configuration ---

const STOCKFISH_SKILL_LEVELS: { [key: string]: number } = {
  Easy: 5,
  Medium: 10,
  Hard: 15,
};

// --- The Hook ---

export const usePlayAI = (gameInstance: Chess) => {
  const [game, setGame] = useState(gameInstance);
  const gameRef = useRef(game);
  const stockfish = useRef<Worker | null>(null);
  const { currentUser } = useAuth();

  const [capturedBy, setCapturedBy] = useState<{ white: Piece[], black: Piece[] }>({ white: [], black: [] });
  const [isThinking, setIsThinking] = useState(false);
  const [playerTurn, setPlayerTurn] = useState<'White' | 'Black'>('White');
  const [gameResult, setGameResult] = useState<GameResult | null>(null);
  const [moveFrom, setMoveFrom] = useState<Square | ''>('');
  const [optionSquares, setOptionSquares] = useState({});
  const [aiStats, setAiStats] = useState<any>(null);

  useEffect(() => {
    if (!currentUser) return;
    const userRef = doc(db, 'users', currentUser.uid);
    const unsubscribe = onSnapshot(userRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setAiStats(data.aiStats || { gamesPlayed: 0, gamesWon: 0, gamesLost: 0, draws: 0, winPercentage: 0 });
      }
    });
    return () => unsubscribe();
  }, [currentUser]);

  const stats = aiStats;

  useEffect(() => {
    gameRef.current = game;
  }, [game]);

  const checkGameState = useCallback(async (currentGame: Chess) => {
    if (gameResult || !currentUser) return;
    
    let resultType: GameResultType | null = null;
    let message = '';

    if (currentGame.isGameOver()) {
        if (currentGame.isCheckmate()) {
            const isPlayerWinner = currentGame.turn() === 'b';
            resultType = isPlayerWinner ? 'win' : 'loss';
            message = isPlayerWinner ? 'Congratulations! 🎉' : 'Better luck next time! 😢';
        } else if (currentGame.isDraw() || currentGame.isStalemate() || currentGame.isThreefoldRepetition()) {
            resultType = 'draw';
            message = "It's a Draw!";
        }

        if (resultType) {
            setGameResult({ message, type: resultType });
            
            const userRef = doc(db, 'users', currentUser.uid);
            const isWinner = resultType === 'win';
            const isDraw = resultType === 'draw';
            
            const currentStats = aiStats || { gamesPlayed: 0, gamesWon: 0, gamesLost: 0, draws: 0, winPercentage: 0 };
            const newGamesPlayed = currentStats.gamesPlayed + 1;
            const newGamesWon = isWinner ? currentStats.gamesWon + 1 : currentStats.gamesWon;
            const newGamesLost = (!isWinner && !isDraw) ? currentStats.gamesLost + 1 : currentStats.gamesLost;
            const newDraws = isDraw ? currentStats.draws + 1 : currentStats.draws;
            const newWinPercentage = Math.round((newGamesWon / newGamesPlayed) * 100);

            await updateDoc(userRef, {
                aiStats: {
                    gamesPlayed: newGamesPlayed,
                    gamesWon: newGamesWon,
                    gamesLost: newGamesLost,
                    draws: newDraws,
                    winPercentage: newWinPercentage
                }
            });
        }
    }
  }, [gameResult, currentUser, aiStats]);

  useEffect(() => {
    const sf = new Worker('/stockfish.js');
    sf.postMessage('uci');
    sf.postMessage('isready');

    sf.onmessage = (event) => {
        const message = event.data;
        if (message.startsWith('bestmove')) {
            const bestMove = message.split(' ')[1];
            if (bestMove && bestMove !== '(none)') {
                const gameCopy = new Chess(gameRef.current.fen());
                const moveResult = gameCopy.move(bestMove, { sloppy: true });
                if (moveResult) {
                    setGame(gameCopy);
                    processMove(gameCopy, moveResult);
                    setPlayerTurn('White');
                    checkGameState(gameCopy);
                }
            }
            setIsThinking(false);
        }
    };
    stockfish.current = sf;

    return () => {
      sf.terminate();
    };
  }, [checkGameState]);

  const makeAIMove = useCallback(() => {
    if (game.isGameOver() || game.turn() !== 'b' || !stockfish.current) {
      return;
    }

    setIsThinking(true);
    const aiLevel = aiStats?.gamesPlayed > 5 ? 'Medium' : 'Easy';
    const skillLevel = STOCKFISH_SKILL_LEVELS[aiLevel] || 5;
    
    stockfish.current.postMessage(`setoption name Skill Level value ${skillLevel}`);
    stockfish.current.postMessage(`position fen ${game.fen()}`);
    stockfish.current.postMessage('go movetime 1500');

  }, [game, aiStats?.gamesPlayed]);

  useEffect(() => {
    if (playerTurn === 'Black' && !game.isGameOver()) {
      const timer = setTimeout(makeAIMove, 750);
      return () => clearTimeout(timer);
    }
  }, [playerTurn, game, makeAIMove]);

  const processMove = (currentGame: Chess, move: Move) => {
    if (move.captured) {
      const capturedColor = move.color === 'w' ? 'black' : 'white';
      const piece: Piece = { type: move.captured, color: move.color === 'w' ? 'b' : 'w' };
      setCapturedBy(prev => ({
        ...prev,
        [capturedColor]: [...prev[capturedColor], piece]
      }));
    }
  };

  function onSquareClick(square: Square) {
    if (playerTurn !== 'White' || game.isGameOver() || isThinking) return;

    if (!moveFrom) {
        const moves = game.moves({ square, verbose: true });
        if (moves.length > 0) {
            setMoveFrom(square);
            setOptionSquares(moves.reduce((acc, m) => ({ ...acc, [m.to]: { background: 'radial-gradient(circle, rgba(0,0,0,.1) 25%, transparent 25%)', borderRadius: '50%' } }), {}));
        }
        return;
    }

    const gameCopy = new Chess(game.fen());
    const moveResult = gameCopy.move({ from: moveFrom, to: square, promotion: 'q' });

    if (moveResult === null) {
        const newPiece = game.get(square);
        if (newPiece && newPiece.color === game.turn()) {
            setMoveFrom(square);
            const newMoves = game.moves({ square, verbose: true });
            setOptionSquares(newMoves.reduce((acc, m) => ({ ...acc, [m.to]: { background: 'radial-gradient(circle, rgba(0,0,0,.1) 25%, transparent 25%)', borderRadius: '50%' } }), {}));
        } else {
            setMoveFrom('');
            setOptionSquares({});
        }
        return;
    }
    
    setGame(gameCopy);
    processMove(gameCopy, moveResult);
    setPlayerTurn('Black');
    checkGameState(gameCopy);
    setMoveFrom('');
    setOptionSquares({});
  }

  const resetGame = () => {
    const newGame = new Chess();
    setGame(newGame);
    setCapturedBy({ white: [], black: [] });
    setPlayerTurn('White');
    setGameResult(null);
    setMoveFrom('');
    setOptionSquares({});
    setIsThinking(false);
  };

  const handleResetStats = async () => {
    if (!currentUser) return;
    const userRef = doc(db, 'users', currentUser.uid);
    await updateDoc(userRef, {
      aiStats: { gamesPlayed: 0, gamesWon: 0, gamesLost: 0, draws: 0, winPercentage: 0 }
    });
    resetGame();
  };

  const closeModal = () => {
    setGameResult(null);
    resetGame();
  };

  return { game, capturedBy, playerTurn, gameResult, stats, onSquareClick, optionSquares, resetGame, closeModal, resetStats: handleResetStats, isThinking };
};