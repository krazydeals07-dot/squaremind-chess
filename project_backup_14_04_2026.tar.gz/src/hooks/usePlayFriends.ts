import { useState, useEffect, useCallback, useMemo } from 'react';
import { doc, onSnapshot, updateDoc, arrayUnion, DocumentData, getDoc, runTransaction, collection, setDoc, serverTimestamp, addDoc } from 'firebase/firestore';
import { Chess, Square, Piece } from 'chess.js';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { GameResultType, GameData } from '../types';

interface GameResult {
    message: string;
    result: GameResultType;
}

export const usePlayFriends = (gameId: string, initialGameData: GameData) => {
    const { currentUser } = useAuth();
    const navigate = useNavigate();
    const userId = currentUser?.uid;

    const [game, setGame] = useState(new Chess(initialGameData.fen));
    const [gameData, setGameData] = useState<DocumentData | null>(initialGameData);
    const [capturedBy, setCapturedBy] = useState<{ white: Piece[], black: Piece[] }>({ white: [], black: [] });
    const [gameResult, setGameResult] = useState<GameResult | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [fromSquare, setFromSquare] = useState<Square | null>(null);
    const [optionSquares, setOptionSquares] = useState<{ [key: string]: React.CSSProperties }>({});

    const { playerColor, boardOrientation } = useMemo(() => {
        if (!gameData || !userId) return { playerColor: 'w', boardOrientation: 'white' };
        const pColor = gameData.players.white === userId ? 'w' : 'b';
        const bOrientation = pColor === 'w' ? 'white' : 'black';
        return { playerColor: pColor, boardOrientation: bOrientation };
    }, [gameData?.players, userId]);

    useEffect(() => {
        if (!gameId || !userId) return;

        const gameDocRef = doc(db, 'games', gameId);
        const unsubscribe = onSnapshot(gameDocRef, (docSnap) => {
            if (docSnap.exists()) {
                const data = docSnap.data();
                 if (data.nextGameId && data.status === 'ended') {
                    navigate(`/game/friends/${data.nextGameId}`, { replace: true });
                    return;
                }
                
                const newGame = new Chess();
                if (data.moves) {
                    data.moves.forEach((move: string) => {
                        try {
                            newGame.move(move);
                        } catch (e) {
                            console.error("Invalid move in history:", move, e);
                        }
                    });
                }
                setGame(newGame);
                setGameData(data);

                const history = newGame.history({ verbose: true });
                const whiteCaptured: Piece[] = [];
                const blackCaptured: Piece[] = [];
                history.forEach(move => {
                    if (move.captured) {
                        const capturedColor = move.color === 'w' ? 'b' : 'w';
                        const piece: Piece = { type: move.captured, color: capturedColor };
                        if (move.color === 'w') {
                            whiteCaptured.push(piece);
                        } else {
                            blackCaptured.push(piece);
                        }
                    }
                });
                setCapturedBy({ white: whiteCaptured, black: blackCaptured });

                if (data.status === 'waiting' && data.players.black === null && data.players.white !== userId) {
                    updateDoc(gameDocRef, {
                        'players.black': userId,
                        status: 'ongoing'
                    }).catch(err => console.error("Error joining game: ", err));
                }

            } else {
                console.error("Game not found");
                navigate('/play/friends');
            }
        });

        return () => unsubscribe();
    }, [gameId, userId, navigate]);

    // Effect to end the game (run by white player only to prevent race conditions)
    useEffect(() => {
        const runGameOverTransaction = async () => {
            if (game.isGameOver() && gameData?.status === 'ongoing' && userId === gameData.players.white) {
                const gameDocRef = doc(db, 'games', gameId);
                try {
                    await runTransaction(db, async (transaction) => {
                        const freshGameDoc = await transaction.get(gameDocRef);
                        if (!freshGameDoc.exists() || freshGameDoc.data().status !== 'ongoing') {
                            return; // Game already over
                        }

                        const winnerColor = game.turn() === 'w' ? 'b' : 'w';
                        const resultType = game.isDraw() || game.isStalemate() ? 'draw' : 'win';
                        const winnerId = resultType === 'win' 
                            ? gameData.players[winnerColor === 'w' ? 'white' : 'black'] 
                            : undefined;
                        
                        transaction.update(gameDocRef, {
                            status: 'gameOver',
                            result: { winnerId, resultType, message: 'Game Over' }
                        });
                    });
                } catch (error) {
                    console.error("Failed to run game over transaction: ", error);
                }
            }
        };

        runGameOverTransaction();
    }, [game, gameData, gameId, userId]);

    // Effect to update user stats and history (runs on BOTH clients after game is over)
    useEffect(() => {
        const updateUserProfile = async () => {
            if (gameData?.status !== 'gameOver' || !gameData.result || !userId) {
                return;
            }

            const userRef = doc(db, 'users', userId);
            const historyRef = doc(collection(userRef, 'gameHistory'), gameId);

            try {
                const historySnap = await getDoc(historyRef);
                if (historySnap.exists()) {
                    return; // Already processed
                }

                const { resultType, winnerId } = gameData.result;
                const isDraw = resultType === 'draw';
                const isWinner = !isDraw && winnerId === userId;
                const resultForUser = isDraw ? 'draw' : (isWinner ? 'win' : 'loss');

                const opponentUid = userId === gameData.players.white ? gameData.players.black : gameData.players.white;
                const opponentRef = doc(db, 'users', opponentUid);
                const opponentSnap = await getDoc(opponentRef);
                const opponentData = opponentSnap.data();
                const opponentName = opponentData?.displayName || 'Opponent';
                const opponentPhotoURL = opponentData?.photoURL;

                const userDocSnap = await getDoc(userRef);
                const currentStats = userDocSnap.data()?.stats || { gamesPlayed: 0, gamesWon: 0, gamesLost: 0, draws: 0, winPercentage: 0, elo: 1200 };
                
                const newGamesPlayed = currentStats.gamesPlayed + 1;
                const newGamesWon = isWinner ? currentStats.gamesWon + 1 : currentStats.gamesWon;
                const newGamesLost = (!isWinner && !isDraw) ? currentStats.gamesLost + 1 : currentStats.gamesLost;
                const newDraws = isDraw ? currentStats.draws + 1 : currentStats.draws;
                const newElo = isDraw ? currentStats.elo + 5 : (isWinner ? currentStats.elo + 15 : Math.max(800, currentStats.elo - 10));
                const newWinPercentage = newGamesPlayed > 0 ? Math.round((newGamesWon / newGamesPlayed) * 100) : 0;
                
                const updatedStats = {
                    gamesPlayed: newGamesPlayed,
                    gamesWon: newGamesWon,
                    gamesLost: newGamesLost,
                    draws: newDraws,
                    winPercentage: newWinPercentage,
                    elo: newElo
                };

                await updateDoc(userRef, {
                    stats: updatedStats,
                    friendsStats: updatedStats // Keep both in sync for consistency
                });

                await setDoc(historyRef, {
                    gameId,
                    opponent: { uid: opponentUid, name: opponentName, photoURL: opponentPhotoURL },
                    result: resultForUser,
                    playedAt: serverTimestamp()
                });

            } catch (error) {
                console.error("Error updating user profile after game over:", error);
            }
        };

        updateUserProfile();
    }, [gameData, gameId, userId]);

    useEffect(() => {
        const showModal = async () => {
            if (gameData?.status === 'gameOver' && !isModalOpen) {
                const result = gameData.result;
                const userResult = result.resultType === 'draw' ? 'draw' : (result.winnerId === userId ? 'win' : 'loss');
                
                let message = 'The game is a draw!';
                if (result.resultType !== 'draw' && result.winnerId) {
                    const winnerDoc = await getDoc(doc(db, 'users', result.winnerId));
                    const winnerName = winnerDoc.exists() ? (winnerDoc.data()?.displayName || 'Unknown') : 'Unknown';
                    message = `Victory for ${winnerName}!`;
                }

                setGameResult({ message, result: userResult });
                setIsModalOpen(true);
            }
        };
        showModal();
    }, [gameData, isModalOpen, userId]);

    const makeMove = useCallback(async (move: { from: Square, to: Square, promotion?: string }) => {
        if (game.isGameOver() || game.turn() !== playerColor) return null;
        const gameCopy = new Chess(game.fen());
        const result = gameCopy.move(move);
        if (result) {
            await updateDoc(doc(db, 'games', gameId), {
                fen: gameCopy.fen(),
                moves: arrayUnion(result.san),
            });
        }
        return result;
    }, [game, playerColor, gameId]);

    const onSquareClick = useCallback(async (square: Square) => {
        if (game.turn() !== playerColor || game.isGameOver()) return;
        if (!fromSquare) {
            const moves = game.moves({ square, verbose: true });
            if (moves.length > 0) {
                setFromSquare(square);
                const newOptionSquares = moves.reduce((acc, move) => {
                    acc[move.to] = {
                        background: game.get(move.to) ? 'radial-gradient(circle, rgba(0,0,0,.1) 85%, transparent 85%)' : 'radial-gradient(circle, rgba(0,0,0,.1) 25%, transparent 25%)',
                        borderRadius: '50%'
                    };
                    return acc;
                }, {} as { [key: string]: React.CSSProperties });
                setOptionSquares(newOptionSquares);
            }
        } else {
            const move = { from: fromSquare, to: square, promotion: 'q' };
            const isMoveLegal = game.moves({ square: fromSquare, verbose: true }).some(m => m.to === square);
            if (isMoveLegal) await makeMove(move);
            setFromSquare(null);
            setOptionSquares({});
        }
    }, [fromSquare, game, makeMove, playerColor]);
    
    const closeModal = useCallback(() => setIsModalOpen(false), []);
    
    const startNewGame = useCallback(async () => {
        if (!gameData?.players) return;
        closeModal();
        const newGameData = {
            players: { white: gameData.players.black, black: gameData.players.white },
            fen: new Chess().fen(),
            status: 'waiting', // Should be waiting for the other player
            createdAt: serverTimestamp(),
            moves: [],
            rematchOf: gameId,
        };
        const newGameRef = await addDoc(collection(db, 'games'), newGameData);
        await updateDoc(doc(db, 'games', gameId), { status: 'ended', nextGameId: newGameRef.id });
    }, [gameData?.players, gameId, closeModal]);

    return {
        game,
        gameData,
        capturedBy,
        gameResult,
        isModalOpen,
        onSquareClick,
        optionSquares,
        closeModal,
        startNewGame,
        boardOrientation,
    };
};