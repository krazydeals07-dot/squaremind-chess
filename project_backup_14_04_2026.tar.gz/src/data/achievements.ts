
import { Achievement } from '../types';

export const achievementsList: Achievement[] = [
    {
        id: 'first_win_ai',
        name: 'First Victory: AI',
        description: 'Win your first game against the AI.',
        icon: '🤖',
    },
    {
        id: 'first_win_friend',
        name: 'First Victory: Friend',
        description: 'Win your first game against a friend.',
        icon: '🤝',
    },
    {
        id: 'ten_wins_ai',
        name: 'AI Conqueror',
        description: 'Win 10 games against the AI.',
        icon: '👑',
    },
    {
        id: 'ten_wins_friend',
        name: 'Social Butterfly',
        description: 'Win 10 games against friends.',
        icon: '🦋',
    },
    {
        id: 'first_tournament_win',
        name: 'Tournament Champion',
        description: 'Win your first tournament.',
        icon: '🏆',
    },
    {
        id: 'flawless_victory',
        name: 'Flawless Victory',
        description: 'Win a game without losing any pieces.',
        icon: '✨',
    },
];
