import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Auth, onAuthStateChanged, User, signInWithEmailAndPassword, getIdTokenResult, signInAnonymously } from 'firebase/auth';
import { auth } from '../firebase';

interface AuthContextType {
    currentUser: User | null;
    loading: boolean;
    isAdmin: boolean;
    isGuest: boolean;
    logout: () => Promise<void>;
    login: (email: string, password: string) => Promise<void>;
    signInAsGuest: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = (): AuthContextType => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};

interface AuthProviderProps {
    children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);
    const [isAdmin, setIsAdmin] = useState(false);
    const [isGuest, setIsGuest] = useState(false);

    useEffect(() => {
        const typedAuth = auth as Auth;
        const unsubscribe = onAuthStateChanged(typedAuth, async (user) => {
            setCurrentUser(user);
            if (user) {
                const isAnonymous = user.isAnonymous;
                setIsGuest(isAnonymous);

                if (isAnonymous) {
                    setIsAdmin(false);
                } else {
                    try {
                        const idTokenResult = await user.getIdTokenResult(true);
                        const isAdminClaim = idTokenResult.claims.isAdmin === true;
                        setIsAdmin(isAdminClaim);
                    } catch (error) {
                        console.error("Error getting ID token result: ", error);
                        setIsAdmin(false);
                    }
                }
            } else {
                setIsAdmin(false);
                setIsGuest(false);
            }
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    const login = async (email: string, password: string) => {
        const typedAuth = auth as Auth;
        await signInWithEmailAndPassword(typedAuth, email, password);
    };

    const signInAsGuest = async () => {
        const typedAuth = auth as Auth;
        await signInAnonymously(typedAuth);
    };

    const logout = async () => {
        try {
            await (auth as Auth).signOut();
            setCurrentUser(null);
            setIsAdmin(false);
            setIsGuest(false);
        } catch (error) {
            console.error("Error signing out: ", error);
        }
    };

    const value: AuthContextType = {
        currentUser,
        loading,
        isAdmin,
        isGuest,
        logout,
        login,
        signInAsGuest,
    };

    return (
        <AuthContext.Provider value={value}>
            {children}
        </AuthContext.Provider>
    );
};