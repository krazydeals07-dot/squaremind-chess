
import {
    collection,
    onSnapshot,
    addDoc,
    updateDoc,
    deleteDoc,
    doc,
    getDoc,
    setDoc,
    Timestamp,
    writeBatch,
    arrayUnion,
    runTransaction,
} from 'firebase/firestore';
import { db } from '../../firebase';
import { UserProfile } from '../../types/user';

// Interfaces (some already exist)
export interface Player {
  uid: string;
  displayName: string;
  elo?: number; // Add elo for sorting
  photoURL?: string;
}

export interface Match {
  id: string;
  round: number;
  player1: Player | null;
  player2: Player | null;
  status: 'pending' | 'ongoing' | 'completed' | 'waiting';
  winnerId?: string | null;
  gameId?: string;
}

export interface Tournament {
    id: string;
    name: string;
    description?: string;
    type: 'Single Elimination' | 'Double Elimination' | 'Round Robin' | 'Swiss' | 'Knockout';
    status: 'upcoming' | 'registration' | 'ongoing' | 'completed' | 'cancelled';
    players: Player[];
    matches: Match[];
    winner?: Player | null;
    createdAt?: Timestamp;
    startDate?: Timestamp | Date;
    endDate?: Timestamp | Date;
    entryFee?: number;
    participantCount?: number; // Already there, good.
    reward?: string;
    maxPlayers?: number | null;
    timeControl?: string;
    autoPairing?: boolean;
    autoStartNextRound?: boolean;
}

// Get Real-time updates for tournaments
export const getTournamentsRT = (
  onUpdate: (tournaments: Tournament[]) => void,
  onError: (error: Error) => void
) => {
  const tournamentsCollection = collection(db, 'tournaments');
  const unsubscribe = onSnapshot(tournamentsCollection,
    (snapshot) => {
      const tournaments = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          // Convert Firestore Timestamps to JS Dates
          startDate: data.startDate?.toDate ? data.startDate.toDate() : data.startDate,
          endDate: data.endDate?.toDate ? data.endDate.toDate() : data.endDate,
        } as Tournament;
      });
      onUpdate(tournaments);
    },
    (error) => {
      console.error("Error fetching tournaments: ", error);
      onError(error);
    }
  );
  return unsubscribe;
};

// Get a single tournament document
export const getTournamentDoc = async (id: string): Promise<Tournament | null> => {
    const docRef = doc(db, 'tournaments', id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
        const data = docSnap.data();
        return {
            id: docSnap.id,
            ...data,
            players: data.players || [],
            matches: data.matches || [],
        } as Tournament;
    }
    return null;
};


// Create a new tournament
export const createTournament = async (tournamentData: Omit<Tournament, 'id'>) => {
    const tournamentsCollection = collection(db, 'tournaments');
    await addDoc(tournamentsCollection, tournamentData);
};

// Create a new tournament with a specific ID
export const createTournamentWithId = async (id: string, tournamentData: Omit<Tournament, 'id'>) => {
    const tournamentRef = doc(db, 'tournaments', id);
    await setDoc(tournamentRef, tournamentData);
};

// Update an existing tournament
export const updateTournament = async (id: string, tournamentData: Partial<Omit<Tournament, 'id'>>) => {
    const tournamentRef = doc(db, 'tournaments', id);
    await updateDoc(tournamentRef, tournamentData);
};

// Delete a tournament
export const deleteTournament = async (id: string) => {
    const tournamentRef = doc(db, 'tournaments', id);
    await deleteDoc(tournamentRef);
};


// Simple shuffle function
const shuffleArray = (array: any[]) => {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// Generate bracket for a tournament
export const generateBracket = async (id: string) => {
    const tournament = await getTournamentDoc(id);
    if (!tournament) throw new Error('Tournament not found');
    if (tournament.status !== 'upcoming' && tournament.status !== 'registration') {
        throw new Error('Tournament must be in "upcoming" or "registration" status to start.');
    }
    if (tournament.players.length < 2) {
        throw new Error('Tournament needs at least 2 players to start.');
    }

    let players = shuffleArray([...tournament.players]); 

    const newMatches: Match[] = [];
    const round = 1;

    for (let i = 0; i < players.length; i += 2) {
        if (i + 1 < players.length) {
            newMatches.push({
                id: `${id}-r${round}-m${(i/2)+1}`,
                round: round,
                player1: players[i],
                player2: players[i+1],
                status: 'pending',
            });
        } else {
             newMatches.push({
                id: `${id}-r${round}-m${(i/2)+1}`,
                round: round,
                player1: players[i],
                player2: null, 
                status: 'completed',
                winnerId: players[i].uid, 
            });
        }
    }

    await updateTournament(id, {
        matches: newMatches,
        status: 'ongoing',
        startDate: new Date(),
    });
};

export const addPlayerToTournament = async (tournamentId: string, player: Player) => {
    const tournamentRef = doc(db, 'tournaments', tournamentId);
    const tournament = await getTournamentDoc(tournamentId);

    if (!tournament) throw new Error('Tournament not found');

    if (tournament.players.some(p => p.uid === player.uid)) {
        throw new Error('Player is already registered in this tournament.');
    }

    if (tournament.maxPlayers && tournament.players.length >= tournament.maxPlayers) {
        throw new Error('Tournament is full.');
    }

    await updateDoc(tournamentRef, {
        players: arrayUnion(player)
    });
};

export const updateMatch = async (tournamentId: string, matchId: string, winnerId: string) => {
    const tournament = await getTournamentDoc(tournamentId);
    if (!tournament) throw new Error("Tournament not found");

    const batch = writeBatch(db);
    const tournamentRef = doc(db, 'tournaments', tournamentId);

    let updatedMatches = tournament.matches.map(m => {
        if (m.id === matchId) {
            return { ...m, status: 'completed', winnerId };
        }
        return m;
    });

    batch.update(tournamentRef, { matches: updatedMatches });
    await batch.commit();

    if (tournament?.autoStartNextRound) {
        await generateNextRound(tournamentId);
    }
};

const recordDailyWinner = async (tournamentId: string, tournamentName: string, winner: Player) => {
    if (!winner) return;

    const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

    const newWinnerRecord = {
        tournamentId: tournamentId,
        tournamentName: tournamentName,
        date: today,
        winners: [
            {
                rank: 1,
                name: winner.displayName,
                prize: 'Champion', // Placeholder prize
                uid: winner.uid
            }
        ]
    };

    const dailyWinnersCol = collection(db, 'dailyWinners');

    try {
        // Create a new document in the `dailyWinners` collection
        await addDoc(dailyWinnersCol, newWinnerRecord);

        // Also, update the user's stats (e.g., daily streak)
        const userRef = doc(db, 'users', winner.uid);
        await runTransaction(db, async (transaction) => {
            const userDoc = await transaction.get(userRef);
            if (!userDoc.exists()) {
                return;
            }
            const currentStreak = userDoc.data().stats?.dailyTournamentStreak || 0;
            transaction.update(userRef, { 'stats.dailyTournamentStreak': currentStreak + 1 });
        });

    } catch (error) {
        console.error("Failed to record daily winner:", error);
    }
};

const resetDailyKnockoutTournament = async () => {
    const tournamentRef = doc(db, 'tournaments', 'daily-knockout');
    await updateDoc(tournamentRef, {
        players: [],
        matches: [],
        status: 'registration',
        winner: null,
        startDate: null,
        endDate: null,
    });
}

export const generateNextRound = async (tournamentId: string) => {
    const tournament = await getTournamentDoc(tournamentId);
    if (!tournament || tournament.status !== 'ongoing') return;

    const currentRound = Math.max(0, ...tournament.matches.map(m => m.round));
    const currentRoundMatches = tournament.matches.filter(m => m.round === currentRound);

    // Check if all matches in the current round are completed
    if (currentRoundMatches.length > 0 && currentRoundMatches.every(m => m.status === 'completed')) {
        const winners = currentRoundMatches
            .map(m => m.winnerId ? tournament.players.find(p => p.uid === m.winnerId) : null)
            .filter((p): p is Player => p !== null && p !== undefined);

        if (winners.length === 1 && currentRoundMatches.length > 0) {
            // Final winner found
            await updateTournament(tournamentId, {
                winner: winners[0],
                status: 'completed',
                endDate: new Date(),
            });

            // Special handling for daily knockout tournament
            if (tournamentId === 'daily-knockout') {
                await recordDailyWinner(tournament.id, tournament.name, winners[0]);
                await resetDailyKnockoutTournament();
            }
            return; // End of tournament
        }

        if (winners.length < 2 && currentRoundMatches.length > 0) {
             // Not enough winners to form a next round, but not a final winner yet. This can happen in odd-numbered brackets.
             // If there is one winner and one bye, the one winner is the final winner. The logic above handles this.
             // If there are zero winners, something is wrong.
             return; 
        }

        const nextRound = currentRound + 1;
        const newMatches: Match[] = [];

        for (let i = 0; i < winners.length; i += 2) {
            if (i + 1 < winners.length) {
                newMatches.push({
                    id: `${tournamentId}-r${nextRound}-m${(i / 2) + 1}`,
                    round: nextRound,
                    player1: winners[i],
                    player2: winners[i + 1],
                    status: 'pending',
                });
            } else {
                // Handle a bye in the next round
                newMatches.push({
                    id: `${tournamentId}-r${nextRound}-m${(i / 2) + 1}`,
                    round: nextRound,
                    player1: winners[i],
                    player2: null,
                    status: 'completed',
                    winnerId: winners[i].uid,
                });
            }
        }
        
        if (newMatches.length > 0) {
             await updateTournament(tournamentId, {
                matches: [...tournament.matches, ...newMatches]
            });
        }
    }
};

export const resetBracket = async (tournamentId: string) => {
    await updateTournament(tournamentId, {
        matches: [],
        status: 'upcoming',
        winner: null,
        startDate: null,
        endDate: null,
    });
};
