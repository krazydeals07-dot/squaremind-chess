import { Timestamp } from 'firebase/firestore';

export interface UserProfile {
    uid: string;
    displayName: string;
    email: string;
    photoURL?: string;
    level?: number;
    aiStats?: Stats;
    friendsStats?: Stats;
    tournamentsStats?: Stats;
    unlockedAchievements?: UnlockedAchievement[];
    mobileNumber?: string;
    dob?: string;
    address?: string;
    country?: string;
}

export interface Stats {
    gamesPlayed: number;
    gamesWon: number;
    gamesLost: number;
    draws: number;
    elo: number;
    winPercentage: number;
}

export interface UnlockedAchievement {
    id: string;
    unlockedAt: Timestamp;
}

export interface GameHistory {
    gameId: string;
    opponent: {
        uid: string;
        name: string;
        photoURL?: string;
    };
    result: 'win' | 'loss' | 'draw';
    playedAt: Timestamp;
}

export type GameResultType = 'win' | 'loss' | 'draw';


export interface GameData {
    fen: string;
    players: {
        white: string;
        black: string | null;
    };
    status: 'waiting' | 'ongoing' | 'gameOver' | 'ended';
    createdAt: any;
    moves?: any[];
    result?: {
        winnerId?: string;
        resultType: GameResultType;
        message: string;
    };
    rematchOf?: string;
    nextGameId?: string;
    tournamentId?: string;
    round?: number;
    playerNames?: {
        white: string;
        black: string;
    };
    chat?: any[];
    timers?: {
        white: number;
        black: number;
    };
    lastMoveTimestamp?: any;
    drawOffer?: {
        from: string;
        to: string;
    };
}
