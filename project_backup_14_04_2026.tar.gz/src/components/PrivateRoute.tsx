import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Box, CircularProgress } from '@mui/material';

interface PrivateRouteProps {
    children: React.ReactElement;
}

const PrivateRoute: React.FC<PrivateRouteProps> = ({ children }) => {
    // Using currentUser and loading from our app's context, as requested
    const { currentUser, loading } = useAuth();

    // While loading → show a centered spinner to prevent rendering before auth state is known
    if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <CircularProgress />
            </Box>
        );
    }

    // If no user after loading → redirect to login page
    if (!currentUser) {
        return <Navigate to="/login" replace />;
    }

    // Safe return: User is loaded and exists, so render the children components
    return children;
};

export default PrivateRoute;
