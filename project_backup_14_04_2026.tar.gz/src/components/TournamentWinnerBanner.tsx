
import React from 'react';
import { Link } from 'react-router-dom';
import { Box, Typography } from '@mui/material';
import { keyframes } from '@emotion/react';

// Define the blinking animation
const blink = keyframes`
  50% {
    opacity: 0.7;
  }
  100% {
    opacity: 1;
  }
`;

const TournamentWinnerBanner = () => {
  return (
    <Link to="/winners" style={{ textDecoration: 'none' }}>
      <Box
        sx={{
          p: { xs: 1.5, md: 2 }, // Responsive padding
          my: { xs: 2, md: 3 }, // Responsive margin
          mx: 'auto',
          maxWidth: '90%',
          background: 'linear-gradient(45deg, #00BCD4, #0097A7)', // More vibrant gradient
          color: 'white', // White text for great contrast
          textAlign: 'center',
          borderRadius: '12px', // Slightly larger border radius
          animation: `${blink} 2.2s linear infinite`,
          cursor: 'pointer',
          border: '1px solid #00838F',
          boxShadow: '0 4px 25px 0 rgba(0, 229, 255, 0.6)', // Brighter, more vibrant cyan glow
          transition: 'all 0.3s ease-in-out',
          '&:hover': {
            backgroundColor: '#0097A7',
            transform: 'scale(1.05)',
            boxShadow: '0 8px 30px 0 rgba(0, 229, 255, 0.8)',
          },
        }}
      >
        <Typography variant="h6" component="h2" sx={{ 
          fontWeight: 'bold', 
          fontSize: { xs: '1rem', sm: '1.2rem' }, // Responsive font size
          textTransform: 'uppercase', 
          letterSpacing: '0.5px' 
        }}>
          🏆 Tournament Winners 🏆
        </Typography>
      </Box>
    </Link>
  );
};

export default TournamentWinnerBanner;
