
import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { Box, Typography, Paper, Grid, Button, Select, MenuItem, FormControl, InputLabel } from '@mui/material';
import { Tournament, Match, Player, updateMatch } from '../../utils/firebase/tournaments';

const MatchCard = ({ match, onUpdateWinner, players }) => {
    const handleWinnerSelection = (e) => {
        const winnerId = e.target.value;
        if (winnerId) {
            onUpdateWinner(match.id, winnerId);
        }
    };

    return (
        <Paper 
            elevation={2} 
            sx={{
                p: 2, 
                mb: 2, 
                backgroundColor: match.status === 'completed' ? '#e0e0e0' : '#fff',
                borderLeft: `4px solid ${
                    match.status === 'completed' ? '#4caf50' : 
                    match.status === 'ongoing' ? '#ff9800' : '#2196f3'
                }`
            }}
        >
            <Typography variant="subtitle2" color="text.secondary">Round {match.round}</Typography>
            <Grid container alignItems="center" justifyContent="space-between">
                <Grid item xs={10}>
                    <Typography variant="body1">{match.player1?.displayName || 'TBD'}</Typography>
                    <Typography variant="caption" sx={{ml: 1}}>vs</Typography>
                    <Typography variant="body1">{match.player2?.displayName || 'TBD'}</Typography>
                </Grid>
                <Grid item xs={2}>
                    {match.status === 'completed' && match.winnerId && (
                        <Typography variant="body2" color="success.main">Winner: {players.find(p => p.uid === match.winnerId)?.displayName}</Typography>
                    )}
                </Grid>
            </Grid>
            {match.status === 'pending' && match.player1 && match.player2 && (
                <FormControl size="small" fullWidth sx={{mt: 1}}>
                    <InputLabel>Set Winner</InputLabel>
                    <Select onChange={handleWinnerSelection} label="Set Winner">
                        <MenuItem value={match.player1.uid}>{match.player1.displayName}</MenuItem>
                        <MenuItem value={match.player2.uid}>{match.player2.displayName}</MenuItem>
                    </Select>
                </FormControl>
            )}
        </Paper>
    );
};

MatchCard.propTypes = {
    match: PropTypes.object.isRequired,
    onUpdateWinner: PropTypes.func.isRequired,
    players: PropTypes.array.isRequired
};

const BracketView = ({ tournament, onUpdate }) => {
    const rounds = useMemo(() => {
        if (!tournament?.matches) return [];
        const groupedByRound = tournament.matches.reduce((acc, match) => {
            (acc[match.round] = acc[match.round] || []).push(match);
            return acc;
        }, {});
        return Object.values(groupedByRound);
    }, [tournament]);

    const handleUpdateWinner = async (matchId: string, winnerId: string) => {
        try {
            await updateMatch(tournament.id, matchId, winnerId);
            if(onUpdate) onUpdate(); // Trigger a re-fetch or state update in the parent
        } catch (error) {
            console.error("Failed to update match winner:", error);
            alert(`Error: ${error.message}`);
        }
    };

    if (!tournament) {
        return <Typography>Select a tournament to view its bracket.</Typography>;
    }

    return (
        <Box sx={{ display: 'flex', overflowX: 'auto', p: 2, gap: 2 }}>
            {rounds.map((roundMatches, index) => (
                <Box key={index} sx={{ minWidth: 300 }}>
                    <Typography variant="h6" sx={{mb: 2, textAlign: 'center'}}>Round {index + 1}</Typography>
                    {roundMatches.map(match => (
                        <MatchCard 
                            key={match.id} 
                            match={match} 
                            onUpdateWinner={handleUpdateWinner} 
                            players={tournament.players}
                        />
                    ))}
                </Box>
            ))}
        </Box>
    );
};

BracketView.propTypes = {
    tournament: PropTypes.object,
    onUpdate: PropTypes.func
};

export default BracketView;
