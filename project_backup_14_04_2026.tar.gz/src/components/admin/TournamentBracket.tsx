
import React from 'react';
import { Box, Typography, Paper } from '@mui/material';
import { styled } from '@mui/material/styles';
import { Match } from '../../utils/firebase/tournaments';

interface TournamentBracketProps {
  matches: Match[];
}

const BracketContainer = styled(Box)({
  display: 'flex',
  overflowX: 'auto',
  padding: '10px',
  color: 'white',
  background: '#0A1F44'
});

const RoundContainer = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  margin: '0 10px',
});

const MatchContainer = styled(Paper)({
  background: '#1A3A6D',
  color: 'white',
  padding: '8px 10px',
  margin: '10px 0',
  width: '150px',
  position: 'relative',
  border: '1px solid #FF6F00',
  borderRadius: '8px'
});

const TournamentBracket: React.FC<TournamentBracketProps> = ({ matches }) => {

  if (!matches || matches.length === 0) {
    return <Typography sx={{color: 'white'}}>Bracket has not been generated yet.</Typography>;
  }

  const rounds: Record<number, Match[]> = matches.reduce((acc, match) => {
    const round = match.round || 0;
    if (!acc[round]) {
      acc[round] = [];
    }
    acc[round].push(match);
    return acc;
  }, {} as Record<number, Match[]>);

  // Sort matches within each round for consistent ordering
  for (const round in rounds) {
      rounds[round].sort((a, b) => (a.matchIndex || 0) - (b.matchIndex || 0));
  }

  const getPlayerStyle = (isWinner: boolean) => ({
    padding: '4px',
    background: isWinner ? '#FF6F00' : 'transparent',
    borderRadius: '4px',
    color: isWinner ? 'black' : 'white',
    fontWeight: isWinner ? 'bold' : 'normal',
  });

  return (
    <BracketContainer>
      {Object.keys(rounds).map(roundKey => {
        const roundNumber = parseInt(roundKey, 10);
        const roundMatches = rounds[roundNumber];
        return (
          <RoundContainer key={roundNumber}>
            <Typography variant="h6" sx={{ color: '#FF6F00', fontSize: '1rem' }}>Round {roundNumber}</Typography>
            <Box>
              {roundMatches.map(match => {
                const isP1Winner = !!(match.winner && match.player1 && match.winner.uid === match.player1.uid);
                const isP2Winner = !!(match.winner && match.player2 && match.winner.uid === match.player2.uid);

                return (
                  <MatchContainer key={match.id}>
                      <Box sx={getPlayerStyle(isP1Winner)}>
                          <Typography noWrap sx={{ fontSize: '0.8rem' }}>{match.player1?.displayName || 'TBD'}</Typography>
                      </Box>
                      <Typography sx={{textAlign: 'center', margin: '2px 0', fontSize: '0.75rem'}}>- vs -</Typography>
                      <Box sx={getPlayerStyle(isP2Winner)}>
                          <Typography noWrap sx={{ fontSize: '0.8rem' }}>{match.player2?.displayName || 'TBD'}</Typography>
                      </Box>
                  </MatchContainer>
                );
              })}
            </Box>
          </RoundContainer>
        );
      })}
    </BracketContainer>
  );
};

export default TournamentBracket;
