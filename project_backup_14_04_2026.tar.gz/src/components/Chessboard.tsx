
import React from 'react';
import { Chessboard as ReactChessboard } from 'react-chessboard';

interface ChessboardProps {
  fen: string;
  onMove: (from: string, to: string) => boolean | Promise<boolean>;
  orientation: 'white' | 'black';
}

const Chessboard: React.FC<ChessboardProps> = ({ fen, onMove, orientation }) => {

  const customPieces = {
    wP: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, backgroundImage: "url(/pieces/wP.svg)", backgroundSize: '100%' }} />,
    wR: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, backgroundImage: "url(/pieces/wR.svg)", backgroundSize: '100%' }} />,
    wN: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, backgroundImage: "url(/pieces/wN.svg)", backgroundSize: '100%' }} />,
    wB: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, backgroundImage: "url(/pieces/wB.svg)", backgroundSize: '100%' }} />,
    wQ: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, backgroundImage: "url(/pieces/wQ.svg)", backgroundSize: '100%' }} />,
    wK: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, backgroundImage: "url(/pieces/wK.svg)", backgroundSize: '100%' }} />,
    bP: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, backgroundImage: "url(/pieces/bP.svg)", backgroundSize: '100%' }} />,
    bR: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, backgroundImage: "url(/pieces/bR.svg)", backgroundSize: '100%' }} />,
    bN: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, backgroundImage: "url(/pieces/bN.svg)", backgroundSize: '100%' }} />,
    bB: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, backgroundImage: "url(/pieces/bB.svg)", backgroundSize: '100%' }} />,
    bQ: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, backgroundImage: "url(/pieces/bQ.svg)", backgroundSize: '100%' }} />,
    bK: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, backgroundImage: "url(/pieces/bK.svg)", backgroundSize: '100%' }} />,
  };

  function onPieceDrop(sourceSquare: string, targetSquare: string) {
    const moveSuccess = onMove(sourceSquare, targetSquare);
    return moveSuccess;
  }

  return (
    <ReactChessboard 
      position={fen} 
      onPieceDrop={onPieceDrop}
      boardOrientation={orientation}
      customPieces={customPieces}
      customBoardStyle={{
        borderRadius: '8px',
        boxShadow: '0 5px 15px rgba(0, 0, 0, 0.5)',
      }}
      customDarkSquareStyle={{ backgroundColor: '#0A1F44' }}
      customLightSquareStyle={{ backgroundColor: '#A6D1FA' }}
    />
  );
};

export default Chessboard;
