import React, { useState, useRef, useMemo } from 'react';
import { Chess, Square, Move } from 'chess.js';
import { Chessboard } from 'react-chessboard';
import { Typography, Paper, Box, Button, Chip } from '@mui/material';
import { Puzzle } from '../../data/puzzles';

interface PuzzleProps {
  puzzle: Puzzle;
  onSolve: (points: number) => void;
  isGuest: boolean;
}

const pieceComponents: { [key: string]: string } = {
    wK: '♚', wQ: '♛', wR: '♜', wB: '♝', wN: '♞', wP: '♟︎',
    bK: '♚', bQ: '♛', bR: '♜', bB: '♝', bN: '♞', bP: '♟︎'
};

const customPieces = {
    wK: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, display: 'flex', justifyContent: 'center', alignItems: 'center' }}><Typography sx={{ fontSize: squareWidth * 0.85, color: '#FFFFFF', textShadow: '0px 2px 4px rgba(0, 0, 0, 0.5)' }}>{pieceComponents.wK}</Typography></div>,
    wQ: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, display: 'flex', justifyContent: 'center', alignItems: 'center' }}><Typography sx={{ fontSize: squareWidth * 0.85, color: '#FFFFFF', textShadow: '0px 2px 4px rgba(0, 0, 0, 0.5)' }}>{pieceComponents.wQ}</Typography></div>,
    wR: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, display: 'flex', justifyContent: 'center', alignItems: 'center' }}><Typography sx={{ fontSize: squareWidth * 0.85, color: '#FFFFFF', textShadow: '0px 2px 4px rgba(0, 0, 0, 0.5)' }}>{pieceComponents.wR}</Typography></div>,
    wB: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, display: 'flex', justifyContent: 'center', alignItems: 'center' }}><Typography sx={{ fontSize: squareWidth * 0.85, color: '#FFFFFF', textShadow: '0px 2px 4px rgba(0, 0, 0, 0.5)' }}>{pieceComponents.wB}</Typography></div>,
    wN: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, display: 'flex', justifyContent: 'center', alignItems: 'center' }}><Typography sx={{ fontSize: squareWidth * 0.85, color: '#FFFFFF', textShadow: '0px 2px 4px rgba(0, 0, 0, 0.5)' }}>{pieceComponents.wN}</Typography></div>,
    wP: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, display: 'flex', justifyContent: 'center', alignItems: 'center' }}><Typography sx={{ fontSize: squareWidth * 0.85, color: '#FFFFFF', textShadow: '0px 2px 4px rgba(0, 0, 0, 0.5)' }}>{pieceComponents.wP}</Typography></div>,
    bK: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, display: 'flex', justifyContent: 'center', alignItems: 'center' }}><Typography sx={{ fontSize: squareWidth * 0.85, color: '#000000', textShadow: '0px 2px 4px rgba(0, 0, 0, 0.5)' }}>{pieceComponents.bK}</Typography></div>,
    bQ: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, display: 'flex', justifyContent: 'center', alignItems: 'center' }}><Typography sx={{ fontSize: squareWidth * 0.85, color: '#000000', textShadow: '0px 2px 4px rgba(0, 0, 0, 0.5)' }}>{pieceComponents.bQ}</Typography></div>,
    bR: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, display: 'flex', justifyContent: 'center', alignItems: 'center' }}><Typography sx={{ fontSize: squareWidth * 0.85, color: '#000000', textShadow: '0px 2px 4px rgba(0, 0, 0, 0.5)' }}>{pieceComponents.bR}</Typography></div>,
    bB: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, display: 'flex', justifyContent: 'center', alignItems: 'center' }}><Typography sx={{ fontSize: squareWidth * 0.85, color: '#000000', textShadow: '0px 2px 4px rgba(0, 0, 0, 0.5)' }}>{pieceComponents.bB}</Typography></div>,
    bN: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, display: 'flex', justifyContent: 'center', alignItems: 'center' }}><Typography sx={{ fontSize: squareWidth * 0.85, color: '#000000', textShadow: '0px 2px 4px rgba(0, 0, 0, 0.5)' }}>{pieceComponents.bN}</Typography></div>,
    bP: ({ squareWidth }: { squareWidth: number }) => <div style={{ width: squareWidth, height: squareWidth, display: 'flex', justifyContent: 'center', alignItems: 'center' }}><Typography sx={{ fontSize: squareWidth * 0.85, color: '#000000', textShadow: '0px 2px 4px rgba(0, 0, 0, 0.5)' }}>{pieceComponents.bP}</Typography></div>,
};

const PuzzleDisplay: React.FC<PuzzleProps> = ({ puzzle, onSolve, isGuest }) => {
  const [game, setGame] = useState(new Chess(puzzle.fen));
  const [message, setMessage] = useState('');
  const [hint, setHint] = useState('');
  const [hintUsed, setHintUsed] = useState(false);
  const chessboardContainerRef = useRef<HTMLDivElement>(null);
  const [moveFrom, setMoveFrom] = useState<Square | ''>('');
  const [optionSquares, setOptionSquares] = useState<{ [key: string]: React.CSSProperties }>({});

  useMemo(() => {
    setGame(new Chess(puzzle.fen));
    setMessage('');
    setHint('');
    setHintUsed(false);
    setMoveFrom('');
    setOptionSquares({});
  }, [puzzle]);

  function makeAMove(move: { from: Square, to: Square, promotion?: string }): boolean {
    const gameCopy = new Chess(game.fen());
    const result = gameCopy.move(move);
    if (result === null) {
      return false; // Illegal move
    }

    setGame(gameCopy);
    setMoveFrom(''); 
    setOptionSquares({});

    const solution = Array.isArray(puzzle.solution) ? puzzle.solution : [puzzle.solution];
    if (solution.includes(result.san)) {
        setMessage('Correct! Puzzle solved.');
        onSolve(puzzle.points);
    } else {
        setMessage('Incorrect move. Try Again');
    }
    return true;
  }

  function onSquareClick(square: Square) {
    if (square === moveFrom) {
        setMoveFrom('');
        setOptionSquares({});
        return;
    }

    if (moveFrom) {
        const moveSuccessful = makeAMove({ from: moveFrom, to: square, promotion: 'q' });
        if (!moveSuccessful) {
            const piece = game.get(square);
            if (piece && piece.color === game.turn()) {
                showMoveOptions(square);
            }
        }
        return;
    }

    const piece = game.get(square);
    if (piece && piece.color === game.turn()) {
        showMoveOptions(square);
    }
  }

  function showMoveOptions(square: Square) {
    const moves = game.moves({ square, verbose: true });
    if (moves.length === 0) {
        return;
    }

    const newOptions: { [key: string]: React.CSSProperties } = {};
    moves.forEach((move: Move) => {
        newOptions[move.to] = {
            background: 'rgba(255, 215, 0, 0.4)',
        };
    });
    newOptions[square] = {
        background: 'rgba(255, 215, 0, 0.5)',
    };
    
    setOptionSquares(newOptions);
    setMoveFrom(square);
  }

  function onPieceDrop(sourceSquare: Square, targetSquare: Square): boolean {
    makeAMove({ from: sourceSquare, to: targetSquare, promotion: 'q' });
    return true;
  }

  const handleShowHint = () => {
    if (isGuest && hintUsed) {
      setMessage("Guests can only use one hint per puzzle.");
      return;
    }
    setHint(puzzle.hint);
    setHintUsed(true);
  };

  const handleShowSolution = () => {
    const solution = Array.isArray(puzzle.solution) ? puzzle.solution.join(', ') : puzzle.solution;
    setMessage(`Solution: ${solution}`);
  };

  const resetPuzzle = () => {
    setGame(new Chess(puzzle.fen));
    setMessage('');
    setHint('');
  };

  return (
    <Paper sx={{ 
        p: 2, 
        background: 'rgba(30, 30, 40, 0.85)', 
        backdropFilter: 'blur(10px)', 
        borderRadius: '15px', 
        color: 'white', 
        width: '100%', 
        boxShadow: '0 0 20px rgba(255, 255, 255, 0.15)',
        maxWidth: '560px',
        mx: 'auto'
    }}>
        <Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                <Typography variant="h6" sx={{ fontFamily: 'Orbitron', color: '#FFA500', fontSize: '1rem' }}>{puzzle.type}</Typography>
                <Box>
                    <Chip size="small" label={puzzle.difficulty} color={puzzle.difficulty === 'Easy' ? 'success' : puzzle.difficulty === 'Medium' ? 'warning' : 'error'} sx={{ mr: 1 }} />
                    <Chip size="small" label={`${puzzle.points} pts`} color="primary" />
                </Box>
            </Box>
            <Typography variant="body2" sx={{ color: 'lightgray', mb: 2 }}>{puzzle.question}</Typography>
        </Box>
        
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 2}}>
            <div ref={chessboardContainerRef} style={{width: '100%', maxWidth: '560px'}}>
                <Chessboard
                    position={game.fen()}
                    onPieceDrop={onPieceDrop}
                    onSquareClick={onSquareClick}
                    customBoardStyle={{ borderRadius: '4px', boxShadow: '0 2px 10px rgba(0, 0, 0, 0.5)' }}
                    customDarkSquareStyle={{ backgroundColor: '#6B3F23' }}
                    customLightSquareStyle={{ backgroundColor: '#EAD8C3' }}
                    customPieces={customPieces}
                    customSquareStyles={optionSquares}
                />
            </div>
        </Box>

        <Box>
            <Box sx={{ mt: 2, display: 'flex', justifyContent: 'center', gap: 1, flexWrap: 'wrap' }}>
                <Button size="small" variant="contained" color="info" onClick={handleShowHint}>Hint</Button>
                <Button size="small" variant="contained" color="secondary" onClick={handleShowSolution}>Solution</Button>
                <Button size="small" variant="outlined" color="warning" onClick={resetPuzzle}>Reset</Button>
            </Box>
            {message && <Typography sx={{ mt: 1, textAlign: 'center', fontSize: '0.875rem', color: message.includes('Correct') ? 'lightgreen' : '#ff7961' }}>{message}</Typography>}
            {hint && <Typography sx={{ mt: 1, textAlign: 'center', fontSize: '0.875rem', color: 'lightblue' }}>Hint: {hint}</Typography>}
        </Box>
    </Paper>
  );
};

export default PuzzleDisplay;
