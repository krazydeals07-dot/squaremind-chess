
import React, { useMemo } from 'react';
import { Chessboard } from 'react-chessboard';
import { Square } from 'chess.js';

// Unicode characters for pieces for a stylish look
const pieceComponents: { [key: string]: string } = {
    wK: '♔', wQ: '♕', wR: '♖', wB: '♗', wN: '♘', wP: '♙',
    bK: '♚', bQ: '♛', bR: '♜', bB: '♝', bN: '♞', bP: '♟︎'
};

// This function creates the 3D-style text pieces
const pieceRenderer = (piece: string, color: string, isBlack: boolean = false) => ({ squareWidth }: { squareWidth: number }) => (
    <div style={{
        width: squareWidth,
        height: squareWidth,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: squareWidth * 0.85, // Adjusted for better fit
        color: color,
        // 3D effect text shadow
        textShadow: isBlack
            ? '-1px -1px 0 #ddd, 1px -1px 0 #ddd, -1px 1px 0 #ddd, 1px 1px 0 #ddd, -2px -2px 8px rgba(0,0,0,0.5)'
            : '0px 2px 5px rgba(0, 0, 0, 0.6)',
        fontFamily: "'Merida', 'Arial', sans-serif" // A nice chess font
    }}>
        {piece}
    </div>
);

// Memoized custom pieces for performance
const customPieces = {
    wK: pieceRenderer(pieceComponents.wK, '#FFFFFF'),
    wQ: pieceRenderer(pieceComponents.wQ, '#FFFFFF'),
    wR: pieceRenderer(pieceComponents.wR, '#FFFFFF'),
    wB: pieceRenderer(pieceComponents.wB, '#FFFFFF'),
    wN: pieceRenderer(pieceComponents.wN, '#FFFFFF'),
    wP: pieceRenderer(pieceComponents.wP, '#FFFFFF'),
    bK: pieceRenderer(pieceComponents.bK, '#1A1A1A', true),
    bQ: pieceRenderer(pieceComponents.bQ, '#1A1A1A', true),
    bR: pieceRenderer(pieceComponents.bR, '#1A1A1A', true),
    bB: pieceRenderer(pieceComponents.bB, '#1A1A1A', true),
    bN: pieceRenderer(pieceComponents.bN, '#1A1A1A', true),
    bP: pieceRenderer(pieceComponents.bP, '#1A1A1A', true),
};

interface StyledChessboardProps {
    position: string;
    onPieceDrop?: (sourceSquare: Square, targetSquare: Square, piece: string) => boolean;
    onSquareClick?: (square: Square) => void;
    onSquareRightClick?: (square: Square) => void;
    boardWidth?: number;
    customSquareStyles?: React.CSSProperties;
    boardOrientation?: 'white' | 'black';
    isDraggablePiece?: ({ piece }: { piece: string }) => boolean;
}

const StyledChessboard: React.FC<StyledChessboardProps> = (props) => {
    return (
        <Chessboard
            {...props}
            customPieces={customPieces}
            customBoardStyle={{
                borderRadius: '8px',
                boxShadow: '0 5px 15px rgba(0, 0, 0, 0.5)',
            }}
            customDarkSquareStyle={{ backgroundColor: '#6B3F23' }}
            customLightSquareStyle={{ backgroundColor: '#EAD8C3' }}
        />
    );
};

export default StyledChessboard;

