import React from 'react';
import { Box, Typography } from '@mui/material';
import { Piece } from 'chess.js';

// Separate objects for white and black pieces for clarity and correctness
const whitePieceComponents: { [key: string]: string } = {
    K: '♔', Q: '♕', R: '♖', B: '♗', N: '♘', P: '♙'
};

const blackPieceComponents: { [key: string]: string } = {
    K: '♚', Q: '♛', R: '♜', B: '♝', N: '♞', P: '♟︎'
};

const PieceDisplay = ({ piece }: { piece: Piece }) => {
    const component = piece.color === 'w' 
        ? whitePieceComponents[piece.type.toUpperCase()] 
        : blackPieceComponents[piece.type.toUpperCase()];
    
    // The color of the SVG icon itself is determined by the component, no need for style color here.
    return (
        <span style={{ fontSize: '24px', margin: '0 2px', filter: piece.color === 'w' ? 'drop-shadow(0 0 1px rgba(0,0,0,0.7))' : 'none' }}>
            {component}
        </span>
    );
};

const CapturedPieces = ({ title, pieces }: { title: string, pieces: Piece[]}) => (
    <Box sx={{ p: 1, textAlign: 'center', background: 'rgba(0,0,0,0.2)', borderRadius: '4px', minHeight: 60 }}>
        <Typography variant="subtitle2" sx={{color: '#ccc', mb: 0.5}}>{title}</Typography>
        <Box sx={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'center', minHeight: '28px' }}>
             {pieces?.map((p, i) => <PieceDisplay key={i} piece={p} />)}
        </Box>
    </Box>
);

export default CapturedPieces;