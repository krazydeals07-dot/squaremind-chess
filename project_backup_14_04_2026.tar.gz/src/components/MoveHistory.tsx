
import React from 'react';
import { Box, Typography, Paper, List, ListItem, Divider } from '@mui/material';
import { Move } from '../types/game';

interface MoveHistoryProps {
    moves: Move[];
}

const MoveHistory: React.FC<MoveHistoryProps> = ({ moves }) => {
    // Pair moves into [white, black] tuples
    const movePairs: [Move, Move | undefined][] = [];
    for (let i = 0; i < moves.length; i += 2) {
        movePairs.push([moves[i], moves[i + 1]]);
    }

    return (
        <Paper elevation={3} sx={{ p: 2, background: '#1E2A3E', color: 'white', height: '100%' }}>
            <Typography variant="h6" sx={{ mb: 1, color: '#FF6F00', textAlign: 'center' }}>Move History</Typography>
            <List sx={{ overflowY: 'auto', height: 'calc(100% - 40px)', pr: 1 }}>
                {movePairs.map((pair, index) => (
                    <React.Fragment key={index}>
                        <ListItem sx={{ py: 0.5 }}>
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                                <Typography sx={{ color: '#e0e0e0', width: '20px' }}>{index + 1}.</Typography>
                                <Typography sx={{ flex: 1, textAlign: 'center', color: 'white' }}>{pair[0].san}</Typography>
                                <Typography sx={{ flex: 1, textAlign: 'center', color: '#bdbdbd' }}>
                                    {pair[1] ? pair[1].san : ''}
                                </Typography>
                            </Box>
                        </ListItem>
                        <Divider sx={{ bgcolor: '#4A6B9C' }} />
                    </React.Fragment>
                ))}
            </List>
        </Paper>
    );
};

export default MoveHistory;
