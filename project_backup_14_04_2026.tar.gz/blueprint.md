# Project Blueprint

## Overview
This document outlines the architecture, features, and development plan for the real-time chess application.

## Core Features
- Real-time multiplayer chess games.
- Tournament functionality with automatic promotion.
- User authentication and profiles.
- Real-time chat during games.
- Leaderboards and player statistics.

## Design & Styling
- **Component Library:** Material-UI (MUI) for a consistent and modern look.
- **Layout:** Responsive design, ensuring a seamless experience on both web and mobile.
- **Aesthetics:** A dark, focused theme suitable for a chess application, with clear typography and intuitive navigation.
- **Visual Effects:** Subtle animations and visual cues for moves, game status, and player turns.

## Architecture
- **Frontend:** React with Vite.
- **Backend & Real-time Database:** Firebase (Firestore).
- **Authentication:** Firebase Authentication.
- **Routing:** `react-router-dom`.

## Refactoring Plan (In Progress)

**Problem:** The `useTournamentGame.ts` hook has grown too large, handling multiple responsibilities (data fetching, game logic, timers, UI state). This violates the Single Responsibility Principle and is likely causing performance issues, including "Resource has been exhausted" errors.

**Solution:** Refactor the monolithic hook into smaller, more focused hooks.

**New Hook Structure:**

1.  **`useGameData.ts`**: 
    - **Responsibility:** All communication with Firestore.
    - **Details:** Manages the `onSnapshot` listener for the game document. Fetches and updates game data, including player names, FEN strings, and moves. Exposes the raw game data and loading/error states.

2.  **`useChessLogic.ts`**:
    - **Responsibility:** All core chess logic.
    - **Details:** Takes the FEN string from `useGameData` as input. Manages the `chess.js` instance. Handles move validation, making moves, and determining game-over states (checkmate, stalemate, draw). Returns the game object, functions to make moves, and game status.

3.  **`useGameTimer.ts`**:
    - **Responsibility:** Player timers.
    - **Details:** Takes timer data and game status from `useGameData` as input. Manages the countdown logic using `setInterval`. Handles timeout conditions and returns the current time for both players.

4.  **`useTournamentGame.ts` (Refactored)**:
    - **Responsibility:** Act as a controller/manager.
    - **Details:** This hook will import and use the three hooks above. It will orchestrate the flow of data between them (e.g., passing the FEN from `useGameData` to `useChessLogic`). It will consolidate the state and functions from the other hooks and provide a clean, unified API to the `LiveTournamentGame.tsx` component.

This new architecture will improve performance, make the code easier to maintain, and resolve the resource exhaustion issues.
